print ("IMPORTING - layout_settings.py")

### IMPORT

#general
import string

#tkinter for UI
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter.font import Font
import tkinter.font as tkfont

#other
from src.modules import _layout as _layout


### CODE

class ui_layout_settings(_layout.layout_base):
    def __init__(self, parent, root):
        self._cfg_layout = {
            "parent": parent,
            "p_root": root,
            "name": "ui_layout_settings",
            "name_simple": "settings"
            }
        super().__init__(self._cfg_layout)

        self.color = "cyan"
        self.frame_margin = 10
        self.frame_spacing = 10

        self.f_main = Frame(self.p.canvas, name = "f_main", width = 0, height = 0, bg="white") #  bg=self.color
        self.lb_title = Label(self.f_main, name = "lb_title", bg="white", text = "Settings",  font= self.p.p.root.font_file_lb_c)

        self.btn1 = Button(self.f_main, text = "Discard", command = self.btn_action_discharge_changes)
        self.btn2 = Button(self.f_main, text = "Load default", command = self.btn_action_loading_default)
        self.btn3 = Button(self.f_main, text = "Save all", command = self.btn_action_save)

        self.c = Canvas(self.f_main, highlightthickness=0, bg="white")

        self.f_content = Frame(self.c, name = "f_content", bg = "white")

        self.f_content_w = self.c.create_window((0, 0), window=self.f_content, anchor="nw", width = 100, height = 500)

        self.scrollbar = Scrollbar(self.f_main, orient='vertical', command=self.c.yview)
        self.c.config(yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=self.c.yview)


        # ######################################################## #
        # adding the setting content here ( fully manual process ) #
        # ######################################################## #
        self.content_height = 0
        self.elem_holder = []

        # setting #1
        self.f_s1 = Frame(self.f_content,  bg = "white", highlightthickness = 1,highlightcolor= "gainsboro", highlightbackground="gainsboro", borderwidth = 1)
        self.f_s1_lb1 = Label(self.f_s1, text = "Safe mode", font= self.p.p.root.font_file_lb_c, anchor = "w", justify= LEFT, bg = "white")
        self.f_s1_lb2 = Label(self.f_s1, text = "When turned on, the application will use the default setting's values, instead of the setting file's values.", font= self.p.p.root.font_file_lb_c_error, anchor = "w", justify= LEFT, bg = "white")
        self.f_s1_lb1.pack( ipadx=10 , fill = X)
        self.f_s1_lb2.pack( ipadx=10 , fill = X)
        self.var1 = IntVar()
        self.f_s1_rb1 = Radiobutton(self.f_s1, text="Safe mode - ON", variable=self.var1, value=1, command=self.radiobutton_action_test, bg = "white")
        self.f_s1_rb2 = Radiobutton(self.f_s1, text="Safe mode - OFF", variable=self.var1, value=2, command=self.radiobutton_action_test, bg = "white")
        self.f_s1_rb1.pack( ipadx=10, side='left')
        self.f_s1_rb2.pack( ipadx=10, side='left')

        self.elem_holder.append([self.f_s1,(self.f_s1_lb1.winfo_reqheight() + self.f_s1_lb2.winfo_reqheight() + 10 + self.f_s1_rb1.winfo_reqheight() + 10)])


        # setting #2
        self.f_s2 = Frame(self.f_content, bg = "white", highlightthickness = 1,highlightcolor= "gainsboro", highlightbackground="gainsboro", borderwidth = 1)
        self.f_s2_lb1 = Label(self.f_s2, text = "Language", font= self.p.p.root.font_file_lb_c, anchor = "w", justify= LEFT, bg = "white")
        self.f_s2_lb2 = Label(self.f_s2, text = "Select the language for the user interface. (Restarting of the application may be requied.)", font= self.p.p.root.font_file_lb_c_error, anchor = "w", justify= LEFT, bg = "white")
        self.f_s2_lb1.pack( ipadx=10 , fill = X)
        self.f_s2_lb2.pack( ipadx=10 , fill = X)

        self.f_s2_cb1 = ttk.Combobox(self.f_s2, name = "cb_selector", font= self.p.p.root.font_file_lb_c)
        self.f_s2_cb1_data = ('English', "Magyar")
        self.f_s2_cb1["values"] = self.f_s2_cb1_data
        self.f_s2_cb1["state"] = "readonly"
        self.f_s2_cb1.place(x = 3, y = self.f_s2_lb1.winfo_reqheight() + self.f_s2_lb2.winfo_reqheight() + 10, width = 400, height = self.f_s2_cb1.winfo_reqheight())
        #self.f_s2_cb1.bind('<<ComboboxSelected>>', self.cb_selector_action)

        self.elem_holder.append([self.f_s2,(self.f_s2_lb1.winfo_reqheight() + self.f_s2_lb2.winfo_reqheight() + 10 + self.f_s2_cb1.winfo_reqheight() + 10)])


        # setting #3
        self.f_s3 = Frame(self.f_content,  bg = "white", highlightthickness = 1,highlightcolor= "gainsboro", highlightbackground="gainsboro", borderwidth = 1)
        self.f_s3_lb1 = Label(self.f_s3, text = "Window mode", font= self.p.p.root.font_file_lb_c, anchor = "w", justify= LEFT, bg = "white")
        self.f_s3_lb2 = Label(self.f_s3, text = "Select which window mode you want the applciation to run.", font= self.p.p.root.font_file_lb_c_error, anchor = "w", justify= LEFT, bg = "white")
        self.f_s3_lb1.pack( ipadx=10 , fill = X)
        self.f_s3_lb2.pack( ipadx=10 , fill = X)

        self.f_s3_cb1 = ttk.Combobox(self.f_s3, name = "cb_selector", font= self.p.p.root.font_file_lb_c)
        self.f_s3_cb1_data = ('Full screen - Bordered', 'Full screen - Borderless', 'Windowed')
        self.f_s3_cb1["values"] = self.f_s3_cb1_data
        self.f_s3_cb1["state"] = "readonly"
        self.f_s3_cb1.place(x = 3, y = self.f_s3_lb1.winfo_reqheight() + self.f_s3_lb2.winfo_reqheight() + 10, width = 400, height = self.f_s3_cb1.winfo_reqheight())
        #self.f_s2_cb1.bind('<<ComboboxSelected>>', self.cb_selector_action)

        self.elem_holder.append([self.f_s3,(self.f_s3_lb1.winfo_reqheight() + self.f_s3_lb2.winfo_reqheight() + 10 + self.f_s3_cb1.winfo_reqheight() + 10)])


        # setting #4
        self.f_s4 = Frame(self.f_content, bg = "white", highlightthickness = 1,highlightcolor= "gainsboro", highlightbackground="gainsboro", borderwidth = 1)
        self.f_s4_lb1 = Label(self.f_s4, text = "Screen resolution and position", font= self.p.p.root.font_file_lb_c, anchor = "w", justify= LEFT, bg = "white")
        self.f_s4_lb2 = Label(self.f_s4, text = "Set screen resolution and position manually. (Other settings may overwrite these values.) ", font= self.p.p.root.font_file_lb_c_error, anchor = "w", justify= LEFT, bg = "white")
        self.f_s4_lb1.pack( ipadx=10 , fill = X)
        self.f_s4_lb2.pack( ipadx=10 , fill = X)

        self.f_s4_e1 = Entry(self.f_s4, bg = "gainsboro", justify= RIGHT)
        self.f_s4_e1_lb = Label(self.f_s4, text = "Width", anchor = "w", justify= LEFT, bg = "white")
        self.f_s4_e2 = Entry(self.f_s4, bg = "gainsboro", justify= RIGHT)
        self.f_s4_e2_lb = Label(self.f_s4, text = "Height", anchor = "w", justify= LEFT, bg = "white")
        self.f_s4_e3 = Entry(self.f_s4, bg = "gainsboro", justify= RIGHT)
        self.f_s4_e3_lb = Label(self.f_s4, text = "X coordinate ( of left-top most corner )", anchor = "w", justify= LEFT, bg = "white")
        self.f_s4_e4 = Entry(self.f_s4, bg = "gainsboro", justify= RIGHT)
        self.f_s4_e4_lb = Label(self.f_s4, text = "Y coordinate ( of left-top most corner )", anchor = "w", justify= LEFT, bg = "white")

        self.f_s4_e1.place(x = 3, y = (self.f_s4_lb1.winfo_reqheight() + self.f_s4_lb2.winfo_reqheight() + 10) + (self.f_s4_e1.winfo_reqheight() * 0) + 0, width = 100, height = self.f_s4_e1.winfo_reqheight() )
        self.f_s4_e1_lb.place(x = 100 + 13, y = (self.f_s4_lb1.winfo_reqheight() + self.f_s4_lb2.winfo_reqheight() + 10) + (self.f_s4_e1.winfo_reqheight() * 0) + 0, width = self.f_s4_e1_lb.winfo_reqwidth(), height = self.f_s4_e1.winfo_reqheight() )

        self.f_s4_e2.place(x = 3, y = (self.f_s4_lb1.winfo_reqheight() + self.f_s4_lb2.winfo_reqheight() + 10) + (self.f_s4_e1.winfo_reqheight() * 1) + 2, width = 100, height = self.f_s4_e2.winfo_reqheight() )
        self.f_s4_e2_lb.place(x = 100 + 13, y = (self.f_s4_lb1.winfo_reqheight() + self.f_s4_lb2.winfo_reqheight() + 10) + (self.f_s4_e1.winfo_reqheight() * 1) + 2, width = self.f_s4_e2_lb.winfo_reqwidth(), height = self.f_s4_e2.winfo_reqheight() )

        self.f_s4_e3.place(x = 3, y = (self.f_s4_lb1.winfo_reqheight() + self.f_s4_lb2.winfo_reqheight() + 10) + (self.f_s4_e1.winfo_reqheight() * 2) + 4, width = 100, height = self.f_s4_e3.winfo_reqheight() )
        self.f_s4_e3_lb.place(x = 100 + 13, y = (self.f_s4_lb1.winfo_reqheight() + self.f_s4_lb2.winfo_reqheight() + 10) + (self.f_s4_e1.winfo_reqheight() * 2) + 4, width = self.f_s4_e3_lb.winfo_reqwidth(), height = self.f_s4_e3.winfo_reqheight() )

        self.f_s4_e4.place(x = 3, y = (self.f_s4_lb1.winfo_reqheight() + self.f_s4_lb2.winfo_reqheight() + 10) + (self.f_s4_e1.winfo_reqheight() * 3) + 6, width = 100, height = self.f_s4_e4.winfo_reqheight() )
        self.f_s4_e4_lb.place(x = 100 + 13, y = (self.f_s4_lb1.winfo_reqheight() + self.f_s4_lb2.winfo_reqheight() + 10) + (self.f_s4_e1.winfo_reqheight() * 3) + 6, width = self.f_s4_e4_lb.winfo_reqwidth(), height = self.f_s4_e4.winfo_reqheight() )

        self.elem_holder.append([self.f_s4,((self.f_s4_lb1.winfo_reqheight() + self.f_s4_lb2.winfo_reqheight() + 10) + (self.f_s4_e1.winfo_reqheight() * 3) + 6 + self.f_s4_e4.winfo_reqheight() + 10)])


        # setting #5
        self.f_s5 = Frame(self.f_content, bg = "white", highlightthickness = 1,highlightcolor= "gainsboro", highlightbackground="gainsboro", borderwidth = 1)
        self.f_s5_lb1 = Label(self.f_s5, text = "Logging", font= self.p.p.root.font_file_lb_c, anchor = "w", justify= LEFT, bg = "white")
        self.f_s5_lb2 = Label(self.f_s5, text = "Turning on, or off the logging feature.", font= self.p.p.root.font_file_lb_c_error, anchor = "w", justify= LEFT, bg = "white")
        self.f_s5_lb1.pack( ipadx=10 , fill = X)
        self.f_s5_lb2.pack( ipadx=10 , fill = X)

        self.var5 = IntVar()
        self.f_s5_rb1 = Radiobutton(self.f_s5, text="Logging - ON", variable=self.var5, value=1, command=self.radiobutton_action_test, bg = "white")
        self.f_s5_rb2 = Radiobutton(self.f_s5, text="Logging - OFF", variable=self.var5, value=2, command=self.radiobutton_action_test, bg = "white")
        self.f_s5_rb1.pack( ipadx=10, side='left')
        self.f_s5_rb2.pack( ipadx=10, side='left')


        self.elem_holder.append([self.f_s5,(self.f_s5_lb1.winfo_reqheight() + self.f_s5_lb2.winfo_reqheight() + 10 + self.f_s5_rb1.winfo_reqheight() + 10)])


        ## setting #6
        #self.f_s6 = Frame(self.f_content, bg = "pink")
        #self.f_s6_lb1 = Label(self.f_s6, text = "Logging method ????", font= self.p.p.root.font_file_lb_c, anchor = "w", justify= LEFT)
        #self.f_s6_lb2 = Label(self.f_s6, text = "This is a description", font= self.p.p.root.font_file_lb_c_error, anchor = "w", justify= LEFT)
        #self.f_s6_lb1.pack( ipadx=10 , fill = X)
        #self.f_s6_lb2.pack( ipadx=10 , fill = X)

        #self.elem_holder.append([self.f_s6,200])


        # setting #7
        self.f_s7 = Frame(self.f_content, bg = "white", highlightthickness = 1,highlightcolor= "gainsboro", highlightbackground="gainsboro", borderwidth = 1)
        self.f_s7_lb1 = Label(self.f_s7, text = "Logging type", font= self.p.p.root.font_file_lb_c, anchor = "w", justify= LEFT, bg = "white")
        self.f_s7_lb2 = Label(self.f_s7, text = "Decide when do you want the logging to take place.", font= self.p.p.root.font_file_lb_c_error, anchor = "w", justify= LEFT, bg = "white")
        self.f_s7_lb1.pack( ipadx=10 , fill = X)
        self.f_s7_lb2.pack( ipadx=10 , fill = X)

        self.f_s7_cb1 = ttk.Combobox(self.f_s7, name = "cb_selector", font= self.p.p.root.font_file_lb_c)
        self.f_s7_cb1_data = ("Saved to file during runtime", "Saved to file on close", "NOT saved to file, runtime stored only")
        self.f_s7_cb1["values"] = self.f_s7_cb1_data
        self.f_s7_cb1["state"] = "readonly"
        self.f_s7_cb1.place(x = 3, y = self.f_s7_lb1.winfo_reqheight() + self.f_s7_lb2.winfo_reqheight() + 10, width = 400, height = self.f_s7_cb1.winfo_reqheight())
        #self.f_s2_cb1.bind('<<ComboboxSelected>>', self.cb_selector_action)

        self.elem_holder.append([self.f_s7,(self.f_s7_lb1.winfo_reqheight() + self.f_s7_lb2.winfo_reqheight() + 10 + self.f_s7_cb1.winfo_reqheight() + 10)])


        # setting #8
        self.f_s8 = Frame(self.f_content, bg = "white", highlightthickness = 1,highlightcolor= "gainsboro", highlightbackground="gainsboro", borderwidth = 1)
        self.f_s8_lb1 = Label(self.f_s8, text = "Log clearing", font= self.p.p.root.font_file_lb_c, anchor = "w", justify= LEFT, bg = "white")
        self.f_s8_lb2 = Label(self.f_s8, text = "Forcing the log file to be complettly rewritten every time the application launches.", font= self.p.p.root.font_file_lb_c_error, anchor = "w", justify= LEFT, bg = "white")
        self.f_s8_lb1.pack( ipadx=10 , fill = X)
        self.f_s8_lb2.pack( ipadx=10 , fill = X)

        self.var8 = IntVar()
        self.f_s8_rb1 = Radiobutton(self.f_s8, text="Log clearing - ON", variable=self.var8, value=1, command=self.radiobutton_action_test, bg = "white")
        self.f_s8_rb2 = Radiobutton(self.f_s8, text="Log clearing - OFF", variable=self.var8, value=2, command=self.radiobutton_action_test, bg = "white")
        self.f_s8_rb1.pack( ipadx=10, side='left')
        self.f_s8_rb2.pack( ipadx=10, side='left')

        self.elem_holder.append([self.f_s8,(self.f_s8_lb1.winfo_reqheight() + self.f_s8_lb2.winfo_reqheight() + 10 + self.f_s8_rb1.winfo_reqheight() + 10)])


        # setting #9
        self.f_s9 = Frame(self.f_content, bg = "white", highlightthickness = 1,highlightcolor= "gainsboro", highlightbackground="gainsboro", borderwidth = 1)
        self.f_s9_lb1 = Label(self.f_s9, text = "Data view - Display Settings ( Filter )", font= self.p.p.root.font_file_lb_c, anchor = "w", justify= LEFT, bg = "white")
        self.f_s9_lb2 = Label(self.f_s9, text = "Should the Display Settings ( Filter ) be hidden by default on the data view menu?", font= self.p.p.root.font_file_lb_c_error, anchor = "w", justify= LEFT, bg = "white")
        self.f_s9_lb1.pack( ipadx=10 , fill = X)
        self.f_s9_lb2.pack( ipadx=10 , fill = X)

        self.var9 = IntVar()
        self.f_s9_rb1 = Radiobutton(self.f_s9, text="Display Settings ( Filter ) - Hidden", variable=self.var9, value=1, command=self.radiobutton_action_test, bg = "white")
        self.f_s9_rb2 = Radiobutton(self.f_s9, text="Display Settings ( Filter ) - Visible", variable=self.var9, value=2, command=self.radiobutton_action_test, bg = "white")
        self.f_s9_rb1.pack( ipadx=10, side='left')
        self.f_s9_rb2.pack( ipadx=10, side='left')

        self.elem_holder.append([self.f_s9,(self.f_s9_lb1.winfo_reqheight() + self.f_s9_lb2.winfo_reqheight() + 10 + self.f_s9_rb1.winfo_reqheight() + 10)])


        # setting #10
        self.f_s10 = Frame(self.f_content, bg = "white", highlightthickness = 1,highlightcolor= "gainsboro", highlightbackground="gainsboro", borderwidth = 1)
        self.f_s10_lb1 = Label(self.f_s10, text = "Screenshot save file format", font= self.p.p.root.font_file_lb_c, anchor = "w", justify= LEFT, bg = "white")
        self.f_s10_lb2 = Label(self.f_s10, text = "Select that in which file format do you want to save the screenshot. ( Default and suggested format is .png )", font= self.p.p.root.font_file_lb_c_error, anchor = "w", justify= LEFT, bg = "white")
        self.f_s10_lb1.pack( ipadx=10 , fill = X)
        self.f_s10_lb2.pack( ipadx=10 , fill = X)

        self.f_s10_cb1 = ttk.Combobox(self.f_s10, name = "cb_selector", font= self.p.p.root.font_file_lb_c)
        self.f_s10_cb1_data = (".png", ".jpg", ".bmp", ".tga")
        self.f_s10_cb1["values"] = self.f_s10_cb1_data
        self.f_s10_cb1["state"] = "readonly"
        self.f_s10_cb1.place(x = 3, y = self.f_s10_lb1.winfo_reqheight() + self.f_s10_lb2.winfo_reqheight() + 10, width = 400, height = self.f_s10_cb1.winfo_reqheight())
        #self.f_s2_cb1.bind('<<ComboboxSelected>>', self.cb_selector_action)

        self.elem_holder.append([self.f_s10,(self.f_s10_lb1.winfo_reqheight() + self.f_s10_lb2.winfo_reqheight() + 10 + self.f_s10_cb1.winfo_reqheight() + 10)])


        ## setting #9
        #self.f_s1 = Frame(self.f_content, bg = "pink")
        #self.f_s1_lb1 = Label(self.f_s1, text = "Title", font= self.p.p.root.font_file_lb_c, anchor = "w", justify= LEFT)
        #self.f_s1_lb2 = Label(self.f_s1, text = "This is a description", font= self.p.p.root.font_file_lb_c_error, anchor = "w", justify= LEFT)
        #self.f_s1_lb1.pack( ipadx=10 , fill = X)
        #self.f_s1_lb2.pack( ipadx=10 , fill = X)

        #self.elem_holder.append([self.f_s1,200])


        self.first_load_in = True

        self.c.bind('<Enter>', lambda event_enter: self._bound_to_mousewheel(event_enter, self.c))
        self.c.bind('<Leave>', self._unbound_to_mousewheel)


    def radiobutton_action_test(self):
        print ("radiobutton_action_test")

    def btn_action_save(self):
        self.p.p.root.p.utility.do_log("Executing: -btn_action_save-  |  Saving settings")

        if (self.var1.get() == 1):
            self.p.p.root.p.settings.safe_mode = True
        else:
            self.p.p.root.p.settings.safe_mode = False
        if (self.var5.get() == 1):
            self.p.p.root.p.settings.logging = True
        else:
            self.p.p.root.p.settings.logging = False
        if (self.var8.get() == 1):
            self.p.p.root.p.settings.logging_clear = True
        else:
            self.p.p.root.p.settings.logging_clear = False

        if (self.var9.get() == 1):
            self.p.p.root.p.settings.data_view_filter_is_shrinked = True
        else:
            self.p.p.root.p.settings.data_view_filter_is_shrinked = False

        self.p.p.root.p.settings.language_cur = self.f_s2_cb1.current()
        self.p.p.root.p.settings.screen_mode = self.f_s3_cb1.current()
        self.p.p.root.p.settings.logging_type = self.f_s7_cb1.current()
        self.p.p.root.p.settings.screenshot_file_format = self.f_s10_cb1.get()

        self.p.p.root.p.settings.screen_whxy = self.p.p.root.p.settings.screen_whxy_converter_to(self.f_s4_e1.get(),self.f_s4_e2.get(),self.f_s4_e3.get(),self.f_s4_e4.get())

        self.p.p.root.p.settings.settings_save()


    def btn_action_loading_default(self):
        self.p.p.root.p.utility.do_log("Executing: -btn_action_loading_default-  |  Loading default settings")
        self.p.p.root.p.settings.settings_load_default()
        self.btn_action_discharge_changes(True)

    def btn_action_discharge_changes(self, b_call_discharge = True):
        self.p.p.root.p.utility.do_log("Executing: -btn_action_discharge_changes-  |  Reset settings page to current values")
        if (self.first_load_in or b_call_discharge):
            self.first_load_in = False
            #radiobuttons
            if (self.p.p.root.p.settings.safe_mode):
                self.var1.set(1)
            else:
                self.var1.set(2)
            if (self.p.p.root.p.settings.logging):
                self.var5.set(1)
            else:
                self.var5.set(2)
            if (self.p.p.root.p.settings.logging_clear):
                self.var8.set(1)
            else:
                self.var8.set(2)
            if (self.p.p.root.p.settings.data_view_filter_is_shrinked):
                self.var9.set(1)
            else:
                self.var9.set(2)
            
            #comboboxes
            if (self.p.p.root.p.settings.language_cur == 0):
                self.f_s2_cb1.current(0)
            elif (self.p.p.root.p.settings.language_cur == 1):
                self.f_s2_cb1.current(1)
            else:
                self.f_s2_cb1.current(0)


            if (self.p.p.root.p.settings.screen_mode == 0):
                self.f_s3_cb1.current(0)
            elif (self.p.p.root.p.settings.screen_mode == 1):
                self.f_s3_cb1.current(1)
            elif (self.p.p.root.p.settings.screen_mode == 2):
                self.f_s3_cb1.current(2)
            else:
                self.f_s3_cb1.current(0)

            if (self.p.p.root.p.settings.logging_type == 0):
                self.f_s7_cb1.current(0)
            elif (self.p.p.root.p.settings.logging_type == 1):
                self.f_s7_cb1.current(1)
            elif (self.p.p.root.p.settings.logging_type == 2):
                self.f_s7_cb1.current(2)
            else:
                self.f_s7_cb1.current(0)

            if (self.p.p.root.p.settings.screenshot_file_format == ".jpg"):
                self.f_s10_cb1.current(1)
            elif (self.p.p.root.p.settings.screenshot_file_format == ".bmp"):
                self.f_s10_cb1.current(2)
            elif (self.p.p.root.p.settings.screenshot_file_format == ".tga"):
                self.f_s10_cb1.current(3)
            else:
                self.f_s10_cb1.current(0)

            _win_coords = self.p.p.root.p.settings.screen_whxy_converter_from()
            self.f_s4_e1.delete(0, tk.END)
            self.f_s4_e1.insert(0, (str(_win_coords[0])))
            self.f_s4_e2.delete(0, tk.END)
            self.f_s4_e2.insert(0, (str(_win_coords[1])))
            self.f_s4_e3.delete(0, tk.END)
            self.f_s4_e3.insert(0, (str(_win_coords[2])))
            self.f_s4_e4.delete(0, tk.END)
            self.f_s4_e4.insert(0, (str(_win_coords[3])))


    def drew(self):
        self.p.b_content_isloading = True
        print ("drawing : " + self.name)

        _f_main_x = self.frame_margin
        _f_main_y = self.frame_margin
        _f_main_w = self.p.canvas.winfo_width() - (self.frame_margin * 2)
        _f_main_h = self.p.canvas.winfo_height() - (self.frame_margin * 2)
        self.f_main.place(x = _f_main_x, y = _f_main_y, width= _f_main_w, height = _f_main_h)

        _cont_w = _f_main_w
        _cont_w_n = _cont_w - (self.frame_margin * 2)
        _cont_w_nm = _cont_w_n - 20


        self.content_height = self.frame_margin
        for i in self.elem_holder:
            #i.pack( ipadx=10 , fill = X, expand = True)
            i[0].place(x = 10, y = self.content_height, width = _cont_w_nm - (self.frame_margin *2), height = i[1])
            self.content_height = self.content_height + i[1] + self.frame_spacing #i.winfo_reqheight()

        # loading in variables, eather loading the already existing ones or the currently selected one
        self.btn_action_discharge_changes(False)

        self.f_s4_e1.delete(0, tk.END)
        self.f_s4_e1.insert(0, (str(self.p.p.root.window.winfo_width())))
        self.f_s4_e2.delete(0, tk.END)
        self.f_s4_e2.insert(0, (str(self.p.p.root.window.winfo_height())))
        self.f_s4_e3.delete(0, tk.END)
        self.f_s4_e3.insert(0, (str(self.p.p.root.window.winfo_x())))
        self.f_s4_e4.delete(0, tk.END)
        self.f_s4_e4.insert(0, (str(self.p.p.root.window.winfo_y())))


        _cont_h = self.content_height

        self.lb_title.place(x = self.frame_margin, y = self.frame_margin, width = _cont_w_n, height = self.lb_title.winfo_reqheight())
        _btn_w = int((_cont_w_n - (self.frame_margin * 4) - (self.frame_spacing * 2)) / 3)
        _btn_spacing = self.frame_spacing + int((((_cont_w_n - (self.frame_margin * 4))- (self.frame_spacing * 2) - (_btn_w * 3)) / 2))
        self.btn1.place(x = (self.frame_margin * 2), y = self.frame_margin + self.lb_title.winfo_reqheight() + self.frame_spacing, width = _btn_w, height = self.btn1.winfo_reqheight())
        self.btn2.place(x = (self.frame_margin * 2) + _btn_w  + _btn_spacing, y = self.frame_margin + self.lb_title.winfo_reqheight() + self.frame_spacing, width = _btn_w, height = self.btn1.winfo_reqheight())
        self.btn3.place(x = (self.frame_margin * 2) + (_btn_w  + _btn_spacing) * 2, y = self.frame_margin + self.lb_title.winfo_reqheight() + self.frame_spacing, width = _btn_w, height = self.btn1.winfo_reqheight())

        _real_content_height = (_f_main_h - (self.frame_margin + self.lb_title.winfo_reqheight() + self.frame_spacing + self.btn1.winfo_reqheight() + self.frame_margin + self.frame_margin ))
        self.c.place(x = self.frame_margin, y = (self.frame_margin + self.lb_title.winfo_reqheight() + self.frame_spacing + self.btn1.winfo_reqheight()+ self.frame_spacing), width = _cont_w_nm, height = _real_content_height)

        self.scrollbar.place(x = self.frame_margin + _cont_w_nm, y = (self.frame_margin + self.lb_title.winfo_reqheight() + self.frame_spacing + self.btn1.winfo_reqheight()+ self.frame_spacing), width = 20, height =  _real_content_height)
        
        self.c.itemconfig(self.f_content_w, width = _cont_w_nm, height= _cont_h)
        self.c.config(scrollregion=(0, 0, _cont_w_nm, _cont_h))


        self.f_main.update()
        self.p.b_content_isloading = False

