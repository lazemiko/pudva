print ("IMPORTING - layout_close.py")

### IMPORT

#general
import string

#tkinter for UI
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter.font import Font
import tkinter.font as tkfont

#other
from src.modules import _layout as _layout


### CODE

class ui_layout_close(_layout.layout_base):
    def __init__(self, parent, root):
        self._cfg_layout = {
            "parent": parent,
            "p_root": root,
            "name": "ui_layout_close",
            "name_simple": "close"
            #"color_bg" : "white"
            #"m_frame_margin" : 10
            }
        super().__init__(self._cfg_layout)


        self.frame_xywh = [0.5,0.5,350,100]
        self.btn_xywh = [0,0,115,40]

        self.color = "white"
        self.frame_margin = 10

        self.f_main = Frame(self.p.canvas, name = "f_main", width = 0, height = 0, bg=self.color)
        self.frame = Frame(self.f_main, name = "frame", highlightthickness=1,highlightbackground="black")
        self.lb1 = Label(self.frame, name="lb1", text="Are you sure, you want to close the application?", anchor="w")
        self.btn1 = Button(self.frame, name="btn1", text = "Yes, Close", command = self.p.p.root.close_app)

        self.lb1.config(font = self.p.p.root.font_cur)

    def drew(self):
        self.p.b_content_isloading = True
        print ("drawing : " + self.name)

        _f_main_x = self.frame_margin
        _f_main_y = self.frame_margin
        _f_main_w = self.p.canvas.winfo_width() - (self.frame_margin * 2)
        _f_main_h = self.p.canvas.winfo_height() - (self.frame_margin * 2)
        self.f_main.place(x = _f_main_x, y = _f_main_y, width= _f_main_w, height = _f_main_h)

        _x = ((self.p.canvas.winfo_width() - self.frame_xywh[2]) * self.frame_xywh[0])
        _y = ((self.p.canvas.winfo_height() - self.frame_xywh[3]) * self.frame_xywh[1])
        _fw = self.lb1.winfo_reqwidth() + (self.frame_margin * 2)
        _fh = self.frame_xywh[3]
        _bw = self.btn1.winfo_reqwidth() + (self.frame_margin * 2) 

        self.frame.place(x = _x, y = _y, width =  _fw, height = _fh)
        self.btn1.place(x = _fw - self.frame_margin - _bw, y = _fh - self.frame_margin - self.btn_xywh[3], width = _bw, height = self.btn_xywh[3])
        self.lb1.place(x = self.frame_margin, y = self.frame_margin, width = _fw - (self.frame_margin * 2), height = self.btn_xywh[3])
        
        self.frame.update()

        self.p.b_content_isloading = False
