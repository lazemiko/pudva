print ("IMPORTING - layout_compare.py")

### IMPORT

#general
import string

#tkinter for UI
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter.font import Font
import tkinter.font as tkfont

#other
from src.modules import _layout as _layout
#import textwrap

### CODE

class ui_layout_compare(_layout.layout_base):
    def __init__(self, parent, root):
        self._cfg_layout = {
            "parent": parent,
            "p_root": root,
            "name": "ui_layout_compare",
            "name_simple": "compare"
            }
        super().__init__(self._cfg_layout)


        self.color = "purple"
        self.frame_margin = 10
        self.frame_spacing = 10

        # TODO : Change to 0
        self.iid = 20   # dunno why 20, also it should store tree filling IDs 

        #ui
        self.f_main = Frame(self.p.canvas, name = "asdddd", width = 0, height = 0, bg="white")
        self.lb_title = Label(self.f_main, name = "lb_title", bg = "white", text = "Compare",  font= self.p.p.root.font_file_lb_c)
        self.cb_selector = ttk.Combobox(self.f_main, name = "cb_selector", font= self.p.p.root.font_file_lb_c)

        #combobox
        self.available_values = []
        if (len(self.p.p.root.p.data.comparable_paths) >0):
            for _x_comp in self.p.p.root.p.data.comparable_paths:
                self.available_values.append(_x_comp[-1])

        self.cb_selector["values"] = self.available_values
        self.cb_selector["state"] = "readonly"
        self.cb_selector.bind('<<ComboboxSelected>>', self.cb_selector_action)

        #trees and scrollbar
        self.tree_initial = ttk.Treeview(self.f_main)
        self.tree_initial.column("#0")
        self.tree_initial.heading("#0",text="Initial",anchor=tk.W)

        self.tree_final = ttk.Treeview(self.f_main)
        self.tree_final.column("#0")
        self.tree_final.heading("#0",text="Final",anchor=tk.W)

        self.tree_scollbar = Scrollbar(self.f_main, orient='vertical')
        self.tree_initial.config(yscrollcommand=self.tree_scollbar.set)
        self.tree_scollbar.config(command= self._on_scrollwheel_event)

        self.tree_initial.bind("<MouseWheel>", lambda event: self._on_mousewheel_init(event, self.tree_initial, self.tree_final))  
        self.tree_final.bind("<MouseWheel>", lambda event: self._on_mousewheel_init(event, self.tree_final, self.tree_initial))

        #slect combobox default
        if (len(self.available_values) > 0):
            self.cb_selector.current(0)
            self.cb_selector_action(None)


    # mouse scroll event init point
    def _on_mousewheel_init(self, event, source, target):
        self._on_mousewheel_init_universal((event.delta), self.tree_initial, self.tree_final)


    #sync the two tree view's scrollbar position
    def _on_mousewheel_init_commit(self, source, target, _new):
        target.yview_moveto(_new)
        source.yview_moveto(_new)


    #calculate the new position of the scroll bar
    def _on_scrollwheel_event(self, *args):
        _input = [*args]
        _val = None
        if (len(_input) == 1):
            _val = int(_input[0])
        elif (len(_input) == 2):
            _val = float(_input[1])
            self.tree_initial.yview_moveto(_val)
            self.tree_final.yview_moveto(_val)
        elif (len(_input) == 3):
            _val = int(_input[1])
        if (_val != None):
            self._on_mousewheel_init_universal((_val * (-1)), self.tree_initial, self.tree_final)
        else:
            self.p.p.utility.do_log("ERROR: something went wrong in function -_on_scrollwheel_event-")


    # calculate scrollbar movement  and than commit
    def _on_mousewheel_init_universal(self, delta, source, target):
        _new = (source.yview()[0])
        try:
            if not (0.0 in [abs(delta)]):
                _new = ((_new) + ((-1*(delta/(abs(delta)))*(source.yview()[1] -_new)) /10))
        except Exception as _error_msg:
            _new = _new
            self.p.p.utility.do_log("ERROR : possible division by zero in function -_on_mousewheel_init_universal-  | " + str(_error_msg))
        if (_new < 0):
            _new = 0
        if (_new > 1):
            _new = 1

        target.yview_moveto(_new)
        source.yview_moveto(_new)

        #committing here
        self.p.p.root.window.after( 10, self._on_mousewheel_init_commit, source, target, _new)


    # clearing trees fully
    def clear_tree(self,v):
        for _i in v.get_children():
            v.delete(_i)

    # tree filling new element get ID
    def get_iid(self):
        self.iid = self.iid + 1
        return self.iid


    # obsolete comparing method
    # TODO : NEed rework and add features
    def do_compare(self):
        _init = self.get_all_children(self.tree_initial)
        _final = self.get_all_children(self.tree_final)
        _error_list = []
        _b = True
        if (len(_init) == len(_final)):
            for _i in range(0, len(_init)):
                _i1 = self.tree_initial.item(_init[_i])["text"]
                _i2 = self.tree_final.item(_final[_i])["text"]
                if (_i1 != _i2):
                    _error_list.append(str([_i1 , _i2]))
                    _b = False
        else:
            _b = False

        if not (_b):
            if (len(_error_list) > 0):
                print ("ERROR: DATA MISMATCH in the following values:")
                for _x in _error_list:
                    print (str(_x))
            else:
                print ("ERROR : compare lenght does not match")
        else:
            print ("DATA MATCH. Data comparison complete.")


    # fetch all children of a tree view
    def get_all_children(self, tree, item=""):
        children = tree.get_children(item)
        for child in children:
            children += self.get_all_children(tree, child)
        return children


    # filling a tree with data
    def recursive_get(self, par, source, b, intendation, insert_parent, target_tree):
        for i in source:
            _s = ""
            for _ll in range(0,intendation):
                _s = _s + "   "
            _b = b
            try:
                if (isinstance(i,dict)):
                    new_folder = target_tree.insert(insert_parent, "end", self.get_iid(), text=str(""), open = True)
                    self.recursive_get(i, i, _b, intendation + 1, new_folder, target_tree)
                else:
                    _i = source[i]
                    if (isinstance(_i,dict)):
                        new_folder = target_tree.insert(insert_parent, "end", self.get_iid(), text=str(i), open = True)
                        self.recursive_get(i, _i, _b, intendation + 1, new_folder, target_tree)
                    else:
                        if ((isinstance(_i,list)) and (len(_i) > 0) and (isinstance(_i[0],dict))):
                            for _y in _i:
                                new_folder = target_tree.insert(insert_parent, "end", self.get_iid(), text=str(i), open = True)
                                self.recursive_get(i, _y, _b, intendation + 1, new_folder, target_tree)
                        else:
                            _s = ""
                            for _ll in range(0,intendation):
                                _s = _s + "   "
                            new_folder = target_tree.insert(insert_parent, "end", self.get_iid(), text=str(i), open = True)
                            target_tree.insert(new_folder, "end", self.get_iid(), text=(str(source[i])),open = True)
            except Exception as _error_msg:
                _s = ""
                self.p.p.utility.do_log("ERROR : Some error has been encountered in function -recursive_get-  | " + str(_error_msg))

    
    # whenever combobox selection changes
    def cb_selector_action(self, event):
        #clear
        self.clear_tree(self.tree_initial)
        self.clear_tree(self.tree_final)

        _target = str(self.cb_selector.get())

        #fill
        self.recursive_get(0, self.p.p.root.p.data.d[_target]["Initial"], True, 0, "", self.tree_initial)
        self.recursive_get(0, self.p.p.root.p.data.d[_target]["Final"], True, 0, "", self.tree_final)
        
        # TODO : Here it should not be the current -do_compare- but instead a more advanced one
        #        that can better check the data, and recolor items in the tree in case of mismatch or missing
        #        Currently the old one is kept here, but it requires work.
        self.do_compare()


    # drawing the layout
    def drew(self):
        self.p.b_content_isloading = True
        print ("drawing : " + self.name)

        _f_main_x = self.frame_margin
        _f_main_y = self.frame_margin
        _f_main_w = self.p.canvas.winfo_width() - (self.frame_margin * 2)
        _f_main_h = self.p.canvas.winfo_height() - (self.frame_margin * 2)
        self.f_main.place(x = _f_main_x, y = _f_main_y, width= _f_main_w, height = _f_main_h)

        _cont_w = _f_main_w - (2 * self.frame_margin)

        # placing UIs
        self.lb_title.place(x = self.frame_margin, y = self.frame_margin, width = _cont_w, height = self.lb_title.winfo_reqheight())
        
        self.cb_selector.place(x = self.frame_margin, y = self.frame_margin + self.lb_title.winfo_reqheight() + self.frame_spacing, width = _cont_w, height = self.cb_selector.winfo_reqheight())

        _tree_y = self.frame_margin + self.lb_title.winfo_reqheight() + self.frame_spacing + self.cb_selector.winfo_reqheight() + self.frame_spacing
        _tree_h = _f_main_h - _tree_y - self.frame_margin

        self.tree_initial.place(x = self.frame_margin, y = _tree_y, width = (_cont_w / 2) - self.frame_spacing - 15, height = _tree_h)
        self.tree_final.place(x = self.frame_margin + (_cont_w / 2) + self.frame_spacing + 15, y = _tree_y, width = (_cont_w / 2) - self.frame_spacing - 15, height = _tree_h)
        self.tree_scollbar.place(x = self.frame_margin + (_cont_w / 2) - 10 , y = _tree_y, width = 20, height = _tree_h)
        
        self.f_main.update()
        self.p.b_content_isloading = False

        
    # previously it was used, but currently not, anyway kept here at the moment
    #def wrap(self, string, lenght=8):
    #    return '\n'.join(textwrap.wrap(string, lenght))