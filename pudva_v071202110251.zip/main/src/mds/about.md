

- Application's name:  {{v_name}}
- Current application version: {{v_version}}

## About the application
This appliaction was created to help analyse and understand the data ( on Windows envronment ), that the Medtronic's Percept PC device generate, and in overall help the decisionmaking process. If you have any feebacks, found a problem, or have a request of what the application should know, feel free to contact me, via the email address provided below. The application was made with the intention of helping the doctors and patients, and not to make money off of it, that is the reason why it is entierly free. In some cases however monetary donations in the form of donations are accepted, but only uppon agreeing to it first, and if the application was in great help of the individual. Special thanks to everyone who helped developing the application.

## Contact
- developed by: {{v_author}}
- email: {{v_contact_email}}
- twitter: {{v_contact_twitter}}
- github: {{v_contact_github}}



## License
Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) - ( https://creativecommons.org/licenses/by-nc/4.0/legalcode )

Short, readable version of the license:

- You are free to:
    - Share — copy and redistribute the material in any medium or format
    - Adapt — remix, transform, and build upon the material


The licensor cannot revoke these freedoms as long as you follow the license terms.

- Under the following terms:
    - Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use.
    - NonCommercial — You may not use the material for commercial purposes.
    - ShareAlike — If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original.
    - No additional restrictions — You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits.



## Changelog
##### Version: v0.7.1.20211025.1
```
Release date: 2021.10.25
Changes:
- Text restructured on pages "Home" and "About"
- Added buttons for Notification page, "Copy to Clipboard" and "Export to file"
Hidden:
- Added modules of "markdown", "requests", and "tkhtmlview", all for the .md text display
- On Data page the date interval buttons now count from the topmost date
- LFP and Amp limits are added, and read from the file.
- On Data page the graph with the limit plots are more readable, a 5% buffer area was added.
- Added option to File page to convert normal data file to anonym version.
- Application packaging now happens in a separate environment dedicated to this process.
```
##### Version: v0.7.1.20210922.1
```
Release date: 2021.09.22
Changes:
- Code cleanup and optimisation.
- Events are properly shown now (EventLog was missing competly, other events appeared incorrectly)
- "Unload File" button was added to clear the currently loaded data
- "Notification" page now records more runtime information ( both detailed error messages, and notifications )
- Application was renamed to "PUDVA" as of ( PerceptPC Unofficial Data Visualizer Application )
- Application is now available on the "github.com" website for download at:
  https://github.com/lazemiko/pudva
```
##### Version: v0.7.0.20210902.1
```
Release date: 2021.09.02
Changes:
- Initial release of this 'preview' version.
```
