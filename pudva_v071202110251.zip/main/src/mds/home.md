
  Attention, the application is still in development. This is a preview version, that is mean to be a show off of various, already working features of the application and looking for feedbacks and requests of how it could be improved.

##### By using the application you agree to the followings:
  * The application is from a third party source, and not associated with Metronic, nor the Percept PC Neurostimulator. ( All usual end user agreement matter applies here as well. See the 'About' menu for more info. )
  * The application is meant to be used as an additional 'helper tool' to the original Metronic Tools. When using the application, make sure you rely on the Metronic one, and use this for additional help.
  * The application is not a final product, but still in development, and there could be issues with it, so when using make sure to keep in mind the application may be wrong at things. Always use the latest version of the application, and if you find a problem or error in it, report it to the developer.
  * The application comes as is, and all responsibility lyies by the end-user.
  * The application usable, copiable, sharable, free of charge, and not at any circumstances or any point ( not in past, present nor future ) you should pay to anyone to be able to use it. If so has happened already, ask for your money back.
  * The application itself, is the intellectual property of the developer, but can be used accodring to the license 'Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)'.
  For more information check the 'About' and 'Help' menus from the left side menubar."



##### Known issues:
 - Language selection and localisation is not yet been implemented fully. Only English language is available at the moment.
 - In case of the Data page showing incorrectly, use the 'Reload' button from the toolbar.
 - On the Data page, the 'Display Settings' currently missing a 'legends' to show which color is for which event.
 - On the Data page, the graph's label-text is sometimes out of range in the Y axis.
 - There could be errors and events that does not show up in the Notification page.
 - Some options are not available in the settings page, or the setting does not load properly.
 - File page will be partially reworked, the three bottom tree-view panel will be replaced with other information.
 - Left side vertical sidebar sometimes does not rectract in size. Similarly the content may not fill the full window. In this case resize the window, it should fix it.
 - If the app's window height-width ratio is too small, part of the SnapShot sidemenu and the listbox may go out of the screen.
