print ("IMPORTING - layout_help.py")

### IMPORT

#general
import string

#tkinter for UI
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter.font import Font
import tkinter.font as tkfont

#for taking screenshot of the app
from PIL import Image, ImageTk
import PIL.Image

#other
from src.modules import _layout as _layout


### CODE

class ui_layout_help(_layout.layout_base):
    def __init__(self, parent, root):
        self._cfg_layout = {
            "parent": parent,
            "p_root": root,
            "name": "ui_layout_help",
            "name_simple": "help"
            }
        super().__init__(self._cfg_layout)


        self.color = "white"
        self.frame_margin = 10
        self.line_spacing = 4

        #title text
        self.f_main = Frame(self.p.canvas, name = "f_main", width = 0, height = 0, bg=self.color)
        self.lb_title = Label(self.f_main, name = "lb_title", text = "Help", anchor="center", font= self.p.p.root.font_file_lb_c)

        #scrollable canvas
        self.c = Canvas(self.f_main, highlightthickness=0)
        self.f_content = Frame(self.c, name = "f_content", bg = "white")
        self.f_content_w = self.c.create_window((0, 0), window=self.f_content, anchor="nw", width = 100, height = 100)
        self.scrollbar = Scrollbar(self.f_main, orient='vertical', command=self.c.yview)

        self.c.config(yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=self.c.yview)

        #text content
        self.txt_intro_head = "Introduction"
        self.txt_intro_body = "\
This application's UI ( User Interface ) has two main area: \n \
    - The vertical side bar on the left side to easiely access vaious menupoints. \n \
    - The right side content area that takes up most of the space and shows the selected menupoint"

        self.txt_sidebar_head = "-- Sidebar --"
        self.txt_sidebar_body = "The sidebar is a self collapsing column, that helps you navigate inside the pplication, and reach everything within a few clicks. \n \
It coinats the following menupoiints: \n \
    1. Home \n \
    2. File load \n \
    3. Data view \n \
    4. Compare  \n \
    5. Help \n \
    6. Screenshot \n \
    7. Settings \n \
    8. Notifications \n \
    9. Quit"

        self.txt_home_head = "-- 1. Home --"
        self.txt_home_body = "The default view that the applicatiom shows once it is started. It shows basic informations, warning, and various other informations."

        self.txt_file_head = "-- 2. File load --"
        self.txt_file_body = "The file load view is for loading a dtat file into the application. To do so, input the correct path address of the file in the top entry field ( recommendedly use the small folder icon to brows the file ), and once that is done use the 'load file' button to load it. Based on the resutl various message will be visible below the entry firld showing that the file was loaded successfully or not. \n \n \
Below that there are some general information about the file that has been loaded. "

        self.txt_data_head = "-- 3. Data view --"
        self.txt_data_body = "The data view is the main part of the application, and you can only access it after successfully loading a datafile to the application in the above menu. \n \n \
The data view is made up of the following areas: \n \
    a. Toolbar on top \n \
    b. Graph - Overview (top) \n \
    c. Graph - Left hemisphere (middle) \n \
    d. Graph - Right hemisphere (bottom) \n \
    e. Right side collapsable menu area \n \n \
---- a. Toolbar on top ---- \n \n \
The Toolbar is the place where you can change the way you see the data.  \n \
It has: \n \
    - from-to manual date input field ( only works within the data limits ) \n \
    - '|->' button will apply the manual from-to date field's values to the graphs. \n \
    - '<<' and '>>' buttons are to jump back or ahead in time by the currently selected time duration \n \
    - '1' - 'All' is the day time duration slectior. For example selecting '7' will show 7 days worth of data only. \n \
    - 'Filter' is to turn on or off the 'Display Settings - Filter' side menu ( see in pont .e ) \n \
    - 'Events' is to turn on or off the 'Event viewer' side menu ( see in pont .e ) \n \
    - 'Reload' is to manually reload the view. It is mainly for testing purpose, and in case of some changes does not apply. \n \n \
---- b. Graph - Overview (top) ---- \n \n \
This graph's view cannot be changed, it only shows an overview of the data. It shows only the left and right hemisphere LFP data, from the first to last recorded date. \n \n \
---- c. Graph - Left hemisphere (middle) ---- \n \n \
Left hemishpere data, that's view can be modified from the 'Display Settings' side menu, and the top toolbar. \n \n \
---- d. Graph - Right hemisphere (bottom) ---- \n \n \
Right hemishpere data, that's view can be modified from the 'Display Settings' side menu, and the top toolbar. \n \n \
---- e. Right side collapsable menu area ---- \n \n \
Depending on the selection this side menu could show: \n \
- 'Display Setting - Filter' that with you can turn on and off various data sets on your Left and Right graphs. \n \
- 'Event viewer' is for viewwing the currently visible events in details, including snapshot graphs. \n "

        self.txt_compare_head = "-- 4. Compare --"
        self.txt_compare_body = "Compare is a menupoint that is meant not to compare files, but data within one file. Some data has 'Initial' and 'Final' form, which can be easily overviewed in this menu, and see if there is any difference between the values. To use it, in the top center dropdown menu, select the data-set that you wish to check, and in the two collumn below the data will be loaded."

        self.txt_help_head = "-- 5. Help --"
        self.txt_help_body = "The menu that you are currently reading. It was ment to help the user understand the way this application works and get an overview ofwhat it is capable of."

        self.txt_screenshot_head = "-- 6. Screenshot --"
        self.txt_screenshot_body = "The only menupoint that does not load new content, but instead it saves the content area of the application. upon ckicking this menupoint, a popup window will appear where you can choose the location of the file where you want to save it. After a few seconds of clicking 'save', the image file will appear in the selected location. The file extension of the file you can change manually in the output field before saving, or you can change the new default file format in the settings menu."

        self.txt_settings_head = "-- 7. Settings --"
        self.txt_settings_body = "Used to change various settings of the application. The settings than saved to a save file in the same folder as wehre the application is, and from that on these settings will be used. On this page each setting is self described, nad does not need any more explonation."

        self.txt_notifications_head = "-- 8. Notifications --"
        self.txt_notifications_body = "This menu is used to see live the various notification that happens while the application is running. Normally the user does not need to brows this menu, but it could give feedback on various actions and possible problemns that happend during the use of this application. If there is a new notification that you haven't seen yet, the notification's icon in the sidebar will get an additional red dot."

        self.txt_quit_head = "-- 9. Quit --"
        self.txt_quit_body = "However the applciation can be closed in various ways, it is recommended to close it as intended, from this menu, using the quit option."

        #config
                #["type", "name", b_created_, objectVar_, textVar_ , b_has_spacing_after, imageSourcePath_, imageVar_, imageVar_Org, imageVar_Unchanged]
        self.config_f_content = [
                ["header", "intro_head", False, None, self.txt_intro_head, False],
                ["text", "intro_body", False, None, self.txt_intro_body, True],
                ["header", "txt_sidebar_head", False, None, self.txt_sidebar_head, False],
                ["text", "txt_sidebar_body", False, None, self.txt_sidebar_body, False],
                ["image", "img_sidebar_body", False, None, "", True, "src/img/app_helper_img_sidebar.png", None, None, None],
                ["header", "txt_home_head", False, None, self.txt_home_head, False],
                ["text", "txt_home_body", False, None, self.txt_home_body, True],
                ["header", "txt_file_head", False, None, self.txt_file_head, False],
                ["text", "txt_file_body", False, None, self.txt_file_body, False],
                ["image", "img_file_body", False, None, "", True, "src/img/app_helper_img_file.png", None, None, None],
                ["header", "txt_data_head", False, None, self.txt_data_head, False],
                ["text", "txt_data_body", False, None, self.txt_data_body, False],
                ["image", "img_data_body", False, None, "", True, "src/img/app_helper_img_data.png", None, None, None],
                ["header", "txt_compare_head", False, None, self.txt_compare_head, False],
                ["text", "txt_compare_body", False, None, self.txt_compare_body, True],
                ["image", "img_compare_body", False, None, "", True, "src/img/app_helper_img_compare.png", None, None, None],
                ["header", "txt_help_head", False, None, self.txt_help_head, False],
                ["text", "txt_help_body", False, None, self.txt_help_body, True],
                ["header", "txt_screenshot_head", False, None, self.txt_screenshot_head, False],
                ["text", "txt_screenshot_body", False, None, self.txt_screenshot_body, True],
                ["header", "txt_settings_head", False, None, self.txt_settings_head, False],
                ["text", "txt_settings_body", False, None, self.txt_settings_body, True],
                ["header", "txt_notifications_head", False, None, self.txt_notifications_head, False],
                ["text", "txt_notifications_body", False, None, self.txt_notifications_body, True],
                ["header", "txt_quit_head", False, None, self.txt_quit_head, False],
                ["text", "txt_quit_body", False, None, self.txt_quit_body, True]
            ]

        self.f_cont_config_processer()

        #scroll binding
        self.c.bind('<Enter>', lambda event_enter: self._bound_to_mousewheel(event_enter, self.c))
        self.c.bind('<Leave>', self._unbound_to_mousewheel)


    #process the content's config, makes a stucture out of it, and places it as well
    def f_cont_config_processer(self, _cont_w_new = 0):
        _xi = 0     # the selected config element, normaly it starts from 0
        _h_cur = 0  # height (y) at which it starts, that should be 0 basically
        for _x in self.config_f_content:
            if (_x[0] == "header"):
                if not(_x[2]):
                    self.config_f_content[_xi][2] = True
                    self.config_f_content[_xi][3] = Label(self.f_content, name = _x[1], text = _x[4], anchor="nw", justify=LEFT, font= self.p.p.root.font_file_lb_c)
                else:
                    _x[3].place(x = 0, y = _h_cur, width = _cont_w_new, height = _x[3].winfo_reqheight())
                    _h_cur = _h_cur + _x[3].winfo_reqheight()
                    if (_x[5]):
                        _h_cur = _h_cur + self.line_spacing

            elif (_x[0] == "text"): 
                if not(_x[2]):
                    self.config_f_content[_xi][2] = True
                    self.config_f_content[_xi][3] = Label(self.f_content, name = _x[1], text = _x[4], anchor="nw", justify=LEFT)
                else:
                    _x[3].config(wraplength=_cont_w_new)
                    _x[3].place(x = 0, y = _h_cur, width = _cont_w_new, height = _x[3].winfo_reqheight())
                    _h_cur = _h_cur + _x[3].winfo_reqheight()
                    if (_x[5]):
                        _h_cur = _h_cur + self.line_spacing
                    
            elif (_x[0] == "image"): 
                if not(_x[2]):
                    self.config_f_content[_xi][2] = True

                    _img = PIL.Image.open(_x[6]) 
                    self.config_f_content[_xi][9] = _img
                    _img_ = ImageTk.PhotoImage(_img)
                    self.config_f_content[_xi][7] = _img_
                    self.config_f_content[_xi][8] = [_img_.width(), _img_.height()]
                    self.config_f_content[_xi][3] = Label(self.f_content, name = self.config_f_content[_xi][1], image=_img_)
                else:
                    _ratio = _cont_w_new / _x[8][0]
                    if (_ratio > 1):
                        _ratio = 1
                    self.config_f_content[_xi][7] = ImageTk.PhotoImage(_x[9].resize((int(_x[8][0] * _ratio), int(_x[8][1] * _ratio)), PIL.Image.ANTIALIAS))
                    _x[3].config(image=_x[7])
                    _x[3].place(x = 0, y = _h_cur, width = _cont_w_new, height = _x[7].height())
                    _h_cur = _h_cur + _x[7].height()
                    if (_x[5]):
                        _h_cur = _h_cur + self.line_spacing
            else:
                print ("ERROR : Soemthing went wrong with help content creation")
                self.p.p.utility.do_log("ERROR : Something went wrong with help content creation. | Please check the -layout_help- config variable's types.")
            _xi = _xi + 1
        return _h_cur


    #drawing the page
    def drew(self, _rec = False):
        self.p.b_content_isloading = True
        print ("drawing : " + self.name)

        _recalculate = _rec

        _f_main_x = self.frame_margin
        _f_main_y = self.frame_margin
        _f_main_w = self.p.canvas.winfo_width() - (self.frame_margin * 2)
        _f_main_h = self.p.canvas.winfo_height() - (self.frame_margin * 2)
        self.f_main.place(x = _f_main_x, y = _f_main_y, width= _f_main_w, height = _f_main_h)

        _cur_h = self.frame_margin
        _cont_w = _f_main_w - (self.frame_margin * 2)
        _cont_w_new = _cont_w - 20
        if _recalculate:
            _cont_w_new = _cont_w_new + 20

        self.lb_title.place(x = self.frame_margin, y = _cur_h , width = _cont_w, height = self.lb_title.winfo_reqheight())
        self.c.place(x = self.frame_margin, y = self.frame_margin + self.lb_title.winfo_reqheight() + self.line_spacing, width = _cont_w_new, height = _f_main_h - (2 * self.frame_margin) - self.lb_title.winfo_reqheight() - self.line_spacing)

        # do the placing and retuns back the height of the scrollable window
        _h_cur = self.f_cont_config_processer(_cont_w_new)

        self.c.itemconfig(self.f_content_w, width = _cont_w, height= _h_cur)

        # this parts hides, or show the scrollabr, based on how the window and content sizes
        if ((_f_main_h - (2 * self.frame_margin) - self.lb_title.winfo_reqheight() - self.line_spacing) < _h_cur):
            self.scrollbar.place( x = self.frame_margin + _cont_w_new, y = self.frame_margin + self.lb_title.winfo_reqheight() + self.line_spacing, width = 20, height = (_f_main_h - (2 * self.frame_margin) - self.lb_title.winfo_reqheight() - self.line_spacing))
            _recalculate = False
        else:
            self.scrollbar.place_forget()
            if (_recalculate):
                _recalculate = False
            else:
                _recalculate = True

        #setting basic scrollbar position
        self.c.config(scrollregion=(0,0,_cont_w,_h_cur))

        self.f_main.update()
        if (_recalculate):
            self.drew(_recalculate)

        self.p.b_content_isloading = False
