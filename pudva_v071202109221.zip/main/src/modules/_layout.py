class layout_base:
    def __init__(self, _cfg):
        self.p = _cfg["parent"]
        self.p_root = _cfg["p_root"]
        self.name = _cfg["name"]
        self.name_simple = _cfg["name_simple"]
        #self.color_bg = _cfg["color_bg"]

    def _bound_to_mousewheel(self, event, target_canv):
        self.c.bind_all("<MouseWheel>", lambda event_wheel: self._on_mousewheel_normal(event_wheel, target_canv))

    def _unbound_to_mousewheel(self, event):
        self.c.unbind_all("<MouseWheel>") 

    def _on_mousewheel_normal(self, event, target_canv):
        _new = (target_canv.yview()[0])
        try:
            _new = ((target_canv.yview()[0]) + ((-1*(event.delta/(abs(event.delta)))*(target_canv.yview()[1] - target_canv.yview()[0])) /10))
        except:
            _new = (target_canv.yview()[0])
            self.p.p.root.p.utility.do_log("ERROR : possible division by zero" + "  at -_on_mousewheel_normal-")
        if (_new < 0):
            _new = 0
        if (_new > 1):
            _new = 1
        target_canv.yview_moveto(_new)


