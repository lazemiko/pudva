print ("IMPORTING - layout_home.py")

### IMPORT

#general
import string

#tkinter for UI
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter.font import Font
import tkinter.font as tkfont

#other
from src.modules import _layout as _layout


### CODE

# TODO : Outsource the text adn make it language change based
class ui_layout_home(_layout.layout_base):
    def __init__(self, parent, root):
        self._cfg_layout = {
            "parent": parent,
            "p_root": root,
            "name": "ui_layout_home",
            "name_simple": "home"
            }
        super().__init__(self._cfg_layout)


        self.color = "brown"
        self.frame_margin = 10
        self.frame_spacing = 10

        self.color_bg = "coral1"

        self.lb_text_known_issue = " \n \
Known issues: \n \
 - Language selection and localisation is partially working. \n \
 - Data menu has performance issues when loading, reloading. Sometimes weird artifacts occure. When that happens, use the 'Reload' button from the toolbar. \n \
 - On the Data menu, the 'Display Settings' currently missing a 'legends' to show which color is for which event.  \n \
 - On the Data menu, the graph's label-text is sometimes out of range in the Y axis. \n \
 - Notification menu does not show every 'notable' event. \n \
 - Some options are not available in the settings menu, or the setting does not load properly . \n \
 - File menu will be partially reworked, the three bottom tree-view panel will be replaced with other information. \n \
 - Left side vertical sidebar sometimes does not rectract in size. \n \
 - If the app's window height-width ratio is too small, part of the SnapShot sidemenu and the listbox may go out of the screen. \n \
 - App's icon on the .exe file and on top of the window is missing. \n"


        self.lb_text_content = "\n \n \
Attention, the application is still in development. This is a preview version, that is mean to be a show off of various, already working features of the application and looking for feedbacks and requests of how it could be improved. \
\n \n" + self.lb_text_known_issue + "\n \n By using the application you agree to the followings: \n \n \
 * The application is from a third party source, and not associated with Metronic, nor the Percept PC Neurostimulator. ( All usual end user agreement matter applies here as well. See the 'About' menu for more info. ) \n \
 * The application is meant to be used as an additional 'helper tool' to the original Metronic Tools. When using the application, make sure you rely on the Metronic one, and use this for additional help. \n \
 * The application is not a final product, but still in development, and there could be issues with it, so when using make sure to keep in mind the application may be wrong at things. Always use the latest version of the application, and if you find a problem or error in it, report it to the developer. \n \
 * The application comes as is, and all responsibility lyies by the end-user. \n \
 * The application usable, copiable, sharable, free of charge, and not at any circumstances or any point ( not in past, present nor future ) you should pay to anyone to be able to use it. If so has happened already, ask for your money back. \n \
 * The application itself, is the intellectual property of the developer, but can be used accodring to the license 'Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)'. \n \n \n \
For more information check the 'About' and 'Help' menus from the left side menubar."


        self.f_main = Frame(self.p.canvas, name = "f_main", width = 0, height = 0, bg=self.color_bg) #bg=self.color
        self.c = Canvas(self.f_main, highlightthickness=0, bg=self.color_bg)
        self.lb_title = Label(self.f_main, name = "lb_title", bg=self.color_bg, text = ("Welcome to the application: " + self.p.p.root.p.info.name),  font= self.p.p.root.font_file_lb_c)
        self.frame_content = Frame(self.c, name = "frame_content", bg=self.color_bg)
        self.lb_content = Label(self.frame_content, name = "lb_content", bg=self.color_bg, anchor="nw",justify= LEFT, font= self.p.p.root.font_file_lb_c2, text = self.lb_text_content)

        self.lb_content_w = self.c.create_window((0, 0), window=self.frame_content, anchor="nw", width = 100, height = 500)

        self.scrollbar = Scrollbar(self.f_main, orient='vertical', command=self.c.yview)
        self.c.config(yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=self.c.yview)

        
        self.c.bind('<Enter>', lambda event_enter: self._bound_to_mousewheel(event_enter, self.c))
        self.c.bind('<Leave>', self._unbound_to_mousewheel)


    def drew(self, stop_recursive = False):
        self.p.b_content_isloading = True
        print ("drawing : " + self.name)

        #if not(stop_recursive):
        #    self.p.p.utility.notification_check_img_status()

        _f_main_x = self.frame_margin
        _f_main_y = self.frame_margin
        _f_main_w = self.p.canvas.winfo_width() - (self.frame_margin * 2)
        _f_main_h = self.p.canvas.winfo_height() - (self.frame_margin * 2)
        self.f_main.place(x = _f_main_x, y = _f_main_y, width= _f_main_w, height = _f_main_h)

        _lb_w = _f_main_w - (self.frame_margin *2)
        _lb_h = _f_main_h - (self.frame_margin *2)
        self.lb_title.place(x = self.frame_margin, y =  self.frame_margin, width = _lb_w, height = 30)

        self.c.place(x = self.frame_margin, y = self.frame_margin + 30 + self.frame_spacing, width = _lb_w, height = _lb_h - self.frame_spacing  - 30)
        

        self.lb_content.config(wraplength=_lb_w - 20)
        self.lb_content.place(x = 0, y = 0, width = _lb_w - 20, height = self.lb_content.winfo_reqheight())
        self.c.itemconfig(self.lb_content_w,width = _lb_w, height= self.lb_content.winfo_reqheight())

        if ((_lb_h - self.frame_spacing - 30) < self.lb_content.winfo_reqheight()):
            self.scrollbar.place( x = self.frame_margin + _lb_w - 20,y = self.frame_margin + 30 + self.frame_spacing, width = 20,height = _lb_h - self.frame_spacing - 30)
        else:
            self.scrollbar.place_forget()

        self.c.config(scrollregion=(0,0,_lb_w,self.lb_content.winfo_reqheight()))


        self.f_main.update()
        self.p.b_content_isloading = False