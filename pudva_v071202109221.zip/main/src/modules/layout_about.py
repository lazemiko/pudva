print ("IMPORTING - layout_about.py")

### IMPORT

#general
import string

#tkinter for UI
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter.font import Font
import tkinter.font as tkfont

#other
from src.modules import _layout as _layout


### CODE

# TODO : Outsource the text adn make it language change based
class ui_layout_about(_layout.layout_base):
    def __init__(self, parent, root):
        self._cfg_layout = {
            "parent": parent,
            "p_root": root,
            "name": "ui_layout_about",
            "name_simple": "about"
            }
        super().__init__(self._cfg_layout)

        self.color = "brown"
        self.frame_margin = 10
        self.frame_spacing = 10

        self.color_bg = "white"

        self.lb_text_content = ""

        self.tx_1 = "\n \n Application's name: " + self.p.p.root.p.info.name + " \n \
Current application version: " + self.p.p.root.p.info.version +  " \n \n \
----- About the application ----- \n\n \
This appliaction was created to help analyse and understand the data ( on Windows envronment ), that the Medtronic's Percept PC device generate, and in overall help the decisionmaking process. \
If you have any feebacks, found a problem, or have a request of what the application should know, feel free to contact me, via the email address provided below. \
The application was made with the intention of helping the doctors and patients, and not to make money off of it, that is the reason why it is entierly free. In some cases however monetary donations in the form of donations are accepted, \
but only uppon agreeing to it first, and if the application was in great help of the individual. Special thanks to everyone who helped developing the application. \n \n " 

        self.tx_2 = "----- Contact ----- \n\n \
developed by:   " + self.p.p.root.p.info.author +  "  \n \
email:   " + self.p.p.root.p.info.contact_email +  "  \n \
twitter:   " + self.p.p.root.p.info.contact_twitter +  "  \n \
github:   " + self.p.p.root.p.info.contact_github +  "  \n \n "

        self.tx_3 = "----- Changelog -----  \n \n \
--- v0.7.0.20210902.1 --- \n \n \
Release date: 2021.09.02 \n \
Changes: \n \
 - Initial release of this 'preview' version.\n \n "

        self.tx_4 = "----- License -----  \n\n \
Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0) - ( https://creativecommons.org/licenses/by-nc/4.0/legalcode ) \n \n \
Short, readable version of the license: \n \n \
You are free to: \n \
 Share — copy and redistribute the material in any medium or format \n \
 Adapt — remix, transform, and build upon the material \n \
 The licensor cannot revoke these freedoms as long as you follow the license terms. \n \n  \
Under the following terms: \n \
 Attribution — You must give appropriate credit, provide a link to the license, and indicate if changes were made. You may do so in any reasonable manner, but not in any way that suggests the licensor endorses you or your use. \n \
 NonCommercial — You may not use the material for commercial purposes. \n \
 ShareAlike — If you remix, transform, or build upon the material, you must distribute your contributions under the same license as the original. \n \
 No additional restrictions — You may not apply legal terms or technological measures that legally restrict others from doing anything the license permits. \n \n "

        self.lb_text_content = self.lb_text_content + "\n" + self.tx_1 + "\n" + self.tx_2 + "\n" + self.tx_3 + "\n" + self.tx_4

        self.f_main = Frame(self.p.canvas, name = "asdddd", width = 0, height = 0, bg=self.color_bg)
        self.c = Canvas(self.f_main, highlightthickness=0,bg=self.color_bg)
        self.lb_title = Label(self.f_main, name = "lb_title", bg=self.color_bg, text = "About",  font= self.p.p.root.font_file_lb_c)
        self.frame_content = Frame(self.c, name = "frame_content", bg=self.color_bg)
        self.lb_content = Label(self.frame_content, name = "lb_content", bg=self.color_bg, anchor="nw",justify= LEFT, font= self.p.p.root.font_file_lb_c2, text = self.lb_text_content)

        self.lb_content_w = self.c.create_window((0, 0), window=self.frame_content, anchor="nw", width = 100, height = 500)

        self.scrollbar = Scrollbar(self.f_main, orient='vertical', command=self.c.yview)
        self.c.config(yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=self.c.yview)

        self.c.bind('<Enter>', lambda event_enter: self._bound_to_mousewheel(event_enter, self.c))
        self.c.bind('<Leave>', self._unbound_to_mousewheel)


    def drew(self, stop_recursive = False):
        self.p.b_content_isloading = True
        print ("drawing : " + self.name)


        _f_main_x = self.frame_margin
        _f_main_y = self.frame_margin
        _f_main_w = self.p.canvas.winfo_width() - (self.frame_margin * 2)
        _f_main_h = self.p.canvas.winfo_height() - (self.frame_margin * 2)
        self.f_main.place(x = _f_main_x, y = _f_main_y, width= _f_main_w, height = _f_main_h)

        _lb_w = _f_main_w - (self.frame_margin *2)
        _lb_h = _f_main_h - (self.frame_margin *2)
        self.lb_title.place(x = self.frame_margin, y =  self.frame_margin, width = _lb_w, height = 30)

        self.c.place(x = self.frame_margin, y = self.frame_margin + 30 + self.frame_spacing, width = _lb_w, height = _lb_h - self.frame_spacing  - 30)
        
        self.lb_content.config(wraplength=_lb_w - 20)
        self.lb_content.place(x = 0, y = 0, width = _lb_w - 20, height = self.lb_content.winfo_reqheight())
        self.c.itemconfig(self.lb_content_w,width = _lb_w, height= self.lb_content.winfo_reqheight())

        if ((_lb_h - self.frame_spacing - 30) < self.lb_content.winfo_reqheight()):
            self.scrollbar.place( x = self.frame_margin + _lb_w - 20,y = self.frame_margin + 30 + self.frame_spacing, width = 20,height = _lb_h - self.frame_spacing - 30)
        else:
            self.scrollbar.place_forget()

        self.c.config(scrollregion=(0,0,_lb_w,self.lb_content.winfo_reqheight()))

        self.f_main.update()
        self.p.b_content_isloading = False

