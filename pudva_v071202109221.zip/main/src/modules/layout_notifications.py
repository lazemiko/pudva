print ("IMPORTING - layout_notifications.py")

### IMPORT

#general
import string

#tkinter for UI
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter.font import Font
import tkinter.font as tkfont

#other
from src.modules import _layout as _layout


### CODE

class ui_layout_notifications(_layout.layout_base):
    def __init__(self, parent, root):
        self._cfg_layout = {
            "parent": parent,
            "p_root": root,
            "name": "ui_layout_notifications",
            "name_simple": "notifications"
            }
        super().__init__(self._cfg_layout)

        self.color = "brown"
        self.frame_margin = 10
        self.frame_spacing = 10

        self.f_main = Frame(self.p.canvas, name = "f_main", width = 0, height = 0, bg="white")
        self.c = Canvas(self.f_main, highlightthickness=0, bg="white")
        self.lb_title = Label(self.f_main, name = "lb_title", bg="white", text = "Notifications",  font= self.p.p.root.font_file_lb_c)
        self.frame_content = Frame(self.c, name = "frame_content", bg="white")
        self.lb_content = Label(self.frame_content, name = "lb_content", bg="white", anchor="nw",justify= LEFT)

        self.lb_content_w = self.c.create_window((0, 0), window=self.frame_content, anchor="nw", width = 100, height = 500)

        self.scrollbar = Scrollbar(self.f_main, orient='vertical', command=self.c.yview)
        self.c.config(yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=self.c.yview)

        self.c.bind('<Enter>', lambda event_enter: self._bound_to_mousewheel(event_enter, self.c))
        self.c.bind('<Leave>', self._unbound_to_mousewheel)


    def drew(self, stop_recursive = False):
        self.p.b_content_isloading = True
        print ("drawing : " + self.name)

        if not(stop_recursive):
            self.p.p.utility.notification_check_img_status()

        _f_main_x = self.frame_margin
        _f_main_y = self.frame_margin
        _f_main_w = self.p.canvas.winfo_width() - (self.frame_margin * 2)
        _f_main_h = self.p.canvas.winfo_height() - (self.frame_margin * 2)
        self.f_main.place(x = _f_main_x, y = _f_main_y, width= _f_main_w, height = _f_main_h)

        _lb_w = _f_main_w - (self.frame_margin *2)
        _lb_h = _f_main_h - (self.frame_margin *2)
        self.lb_title.place(x = self.frame_margin, y =  self.frame_margin, width = _lb_w, height = 30)

        self.c.place(x = self.frame_margin, y = self.frame_margin + 30 + self.frame_spacing, width = _lb_w, height = _lb_h - self.frame_spacing  - 30)
        self.c.itemconfig(self.lb_content_w,width = _lb_w, height= self.lb_content.winfo_reqheight())

        self.lb_content.place(x = 0, y = 0, width = _lb_w - 20, height = self.lb_content.winfo_reqheight())

        if ((_lb_h - self.frame_spacing - 30) < self.lb_content.winfo_reqheight()):
            self.scrollbar.place( x = self.frame_margin + _lb_w - 20,y = self.frame_margin + 30 + self.frame_spacing, width = 20,height = _lb_h - self.frame_spacing - 30)
        else:
            self.scrollbar.place_forget()

        self.c.config(scrollregion=(0,0,_lb_w,self.lb_content.winfo_reqheight()))

        self.f_main.update()
        self.p.b_content_isloading = False
