print ("IMPORTING - layout_about.py")

### IMPORT

#general
import string

#tkinter for UI
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter.font import Font
import tkinter.font as tkfont

#other
from src.modules import _layout as _layout


# html + MD
import markdown
from tkhtmlview import HTMLLabel

### CODE

# TODO : Outsource the text adn make it language change based
class ui_layout_about(_layout.layout_base):
    def __init__(self, parent, root):
        self._cfg_layout = {
            "parent": parent,
            "p_root": root,
            "name": "ui_layout_about",
            "name_simple": "about"
            }
        super().__init__(self._cfg_layout)

        self.color = "brown"
        self.frame_margin = 10
        self.frame_spacing = 10

        self.color_bg = "white"

        self.f_main = Frame(self.p.canvas, name = "asdddd", width = 0, height = 0, bg=self.color_bg)
        self.f_main2 = Frame(self.p.canvas, name = "f_main222", width = 0, height = 0, bg="pink")
        self.lb_title = Label(self.f_main, name = "lb_title", bg=self.color_bg, text = "About",  font= self.p.p.root.font_file_lb_c)


        #html + MD
        self.f = open("src\\mds\\about.md", "r", encoding="utf-8")
        self.ff = self.f.read()
        self.html_code = markdown.markdown(self.ff)

        #replaces with variables
        self.html_code = self.html_code.replace("{{v_name}}", self.p.p.root.p.info.name)
        self.html_code = self.html_code.replace("{{v_version}}", self.p.p.root.p.info.version)
        self.html_code = self.html_code.replace("{{v_author}}", self.p.p.root.p.info.author)
        self.html_code = self.html_code.replace("{{v_contact_email}}", self.p.p.root.p.info.contact_email)
        self.html_code = self.html_code.replace("{{v_contact_twitter}}", self.p.p.root.p.info.contact_twitter)
        self.html_code = self.html_code.replace("{{v_contact_github}}", self.p.p.root.p.info.contact_github)

        self.html_label = HTMLLabel(self.f_main2, html= self.html_code,)
        self.html_label.configure( bg = self.color_bg)
        _a = self.html_label.tag_names()
        for _aa in _a:
            self.html_label.tag_configure(_aa, background = self.color_bg)


        self.scrollbar = Scrollbar(self.f_main2, orient='vertical', command=self.html_label.yview)
        self.html_label.config(yscrollcommand=self.scrollbar.set)
        self.scrollbar.config(command=self.html_label.yview)


    def drew(self, stop_recursive = False):
        self.p.b_content_isloading = True
        print ("drawing : " + self.name)

        _f_main_x = self.frame_margin
        _f_main_y = self.frame_margin
        _f_main_w = self.p.canvas.winfo_width() - (self.frame_margin * 2)
        _f_main_h = self.p.canvas.winfo_height() - (self.frame_margin * 2)
        
        _lb_w = _f_main_w - (self.frame_margin *2)
        _lb_h = _f_main_h - (self.frame_margin *2)
        self.lb_title.configure(wraplength = _lb_w) 
        self.lb_title.place(x = self.frame_margin, y =  self.frame_margin, width = _lb_w, height = self.lb_title.winfo_reqheight() )

        _lbt_ym = self.lb_title.winfo_reqheight() +  self.frame_margin  +  self.frame_margin

        self.f_main.place(x = _f_main_x, y = _f_main_y, width= _f_main_w, height = _lbt_ym)
        self.f_main2.place(x = _f_main_x, y = _lbt_ym, width= _f_main_w, height = _f_main_h - _lbt_ym + self.frame_margin)

        if ((self.html_label.winfo_reqheight() *2) > ( _f_main_h - _lbt_ym)):
            self.html_label.place( x = 0, y = 0, width = _f_main_w - 20, height = _f_main_h - _lbt_ym + self.frame_margin)
            self.scrollbar.place( x = _f_main_w - 20, y = 0, width = 20, height = _f_main_h - _lbt_ym + self.frame_margin)
        else:
            self.html_label.place( x = 0, y = 0, width = _f_main_w, height = _f_main_h - _lbt_ym + self.frame_margin)
            self.scrollbar.place_forget()


        self.f_main.update()
        self.p.b_content_isloading = False

