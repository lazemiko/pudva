print ("IMPORTING - layout_file.py")

### IMPORT

#general
import string
import json
import os
import os.path

#tkinter for UI
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
from tkinter.font import Font
import tkinter.font as tkfont

#other
from src.modules import _layout as _layout

#image
from PIL import Image, ImageTk
import PIL.Image

import datetime
from datetime import datetime


### CODE

# TODO : Later on , the right and middle collun of tree view could be replaced and all three or maybe more data could be show nin one tree view, with a combobox above it
#    so this way it could free up some space. The new space could be used file related data, for example, creation of file, how many event there are in it, which dat from to, etc...
# TODO : In general many things on this page should be reqritten from the basics, similarly how dinamical some other page could look.
class ui_layout_file(_layout.layout_base):
    def __init__(self, parent, root):
        self._cfg_layout = {
            "parent": parent,
            "p_root": root,
            "name": "ui_layout_file",
            "name_simple": "file"
            }
        super().__init__(self._cfg_layout)

        self.iid = 10      # used for tree filling

        self.color = "white"
        self.frame_margin = 10
        self.frame_spacing = 10
        self.f_top_single_height = 30
        self.f_top_btn_w = 150

        #defining ui elements
        self.f_main = Frame(self.p.canvas, name="f_main", bg=self.color)

        #top
        self.f_top = Frame(self.f_main, name = "f_top", bg=self.color)

        #first line
        self.f_line_top = Frame(self.f_top, name="f_line_top", bg=self.color)
        self.f_top_label = Label(self.f_line_top, name="f_top_label", text="Please select the file you want to load in:", anchor="w", font= self.p_root.root.font_file_lb_c, bg= self.color)
        self.f_top_entry = Entry(self.f_line_top, name = "f_top_entry", relief = "solid")
        self.f_top_lb_note = Label(self.f_line_top, name="f_top_lb_note", bg=self.color, text="", anchor="w", font= self.p_root.root.font_file_lb_c_error, fg="red")
        self.f_top_button_browse = Button(self.f_line_top, text = "", command= lambda: self.p_root.data.open_file_browser())

        self.image = PIL.Image.open("src/img/app_ui_icon_brows_folder.png") 
        self.image = self.image.resize((self.f_top_single_height, self.f_top_single_height), PIL.Image.ANTIALIAS)
        self.image_ = ImageTk.PhotoImage(self.image)
        self.f_top_button_browse.configure(image = self.image_)

        self.f_top_button = Button(self.f_line_top, text = "Load file", command= lambda: self.layout_file_load_action())
        self.f_top_button_convert = Button(self.f_line_top, text = "Conv. and save file as Anonym", command= lambda: self.layout_file_convert_action())
        
        #Bottom
        self.f_bottom = Frame(self.f_main, name = "f_bottom", bg=self.color)

        #second line
        self.f_line = Frame(self.f_bottom, name="f_line", bg=self.color)
        self.f_bottom_label = Label(self.f_line, name = "f_bottom_label", text="Currently loaded file:", anchor="w", font= self.p_root.root.font_file_lb_c, bg= self.color)
        self.f_bottom_entry = Entry(self.f_line, name = "f_bottom_entry", relief = "solid", text="loaded file name comes here, otherwise N/A")
        self.f_bottom_entry.config(state='disabled')
        self.f_bottom_button = Button(self.f_line, text = "Unload file", command= lambda: self.layout_file_unload_action(), bg = "red")

        #Trees
        self.f_col_1 = Frame(self.f_bottom, name="f_col_1", bg=self.color)
        self.tree = ttk.Treeview(self.f_bottom)
        self.tree.column("#0")
        self.tree.heading("#0",text="PatientInfo",anchor=tk.W)

        self.f_col_2 = Frame(self.f_bottom, name="f_col_2", bg="blue")
        self.tree2 = ttk.Treeview(self.f_bottom)
        self.tree2.column("#0")
        self.tree2.heading("#0",text="DeviceInfo",anchor=tk.W)

        self.f_col_3 = Frame(self.f_bottom, name="f_col_3", bg="blue")
        self.tree3 = ttk.Treeview(self.f_bottom)
        self.tree3.column("#0")
        self.tree3.heading("#0",text="BatteryInfo",anchor=tk.W)

        self.update_ui_data()


    # load + convert + call export function
    def layout_file_convert_action(self):
        print ("")
        self.p_root.utility.do_log("File conversion process has started.")
        _p = self.f_top_entry.get()
        _b = False
        _d = ""
        self.p_root.utility.do_log("File path is the following: " + (str(_p)))
        if ((_p != "") and (os.path.exists(_p))):
            with open(_p, "r", encoding='utf8') as _f:
                try:
                    _d = (json.load(_f))
                    _b = True
                except Exception as _error_msg:
                    self.p_root.root.content.layout_cur.check_path_consistency("ERROR: Data in file or its structure is unsupported. | " + "Unexpected error:" + str(_error_msg))
        else:
            self.p_root.root.content.layout_cur.check_path_consistency("ERROR: File does not exists.")

        if (_b):
            _repl_val = "███████"

            _s = "PatientInformation"
            if (_s in _d):
                for _y in ["Initial", "Final"]:
                    if (_y in _d[_s]):
                        for _x in ["PatientFirstName", "PatientLastName", "PatientGender", "PatientDateOfBirth", "PatientId"]:
                            if (_x in _d[_s][_y]):
                                _d[_s][_y][_x] = _repl_val

            _s = "DeviceInformation"
            if (_s in _d):
                for _y in ["Initial", "Final"]:
                    if (_y in _d[_s]):
                        for _x in ["NeurostimulatorSerialNumber", "ImplantDate"]:
                            if (_x in _d[_s][_y]):
                                _d[_s][_y][_x] = _repl_val

            self.btn_action_export_to_file(_d, _p)
        else:
            self.p_root.utility.do_log("ERROR: Failed to convert file.")
        self.p_root.utility.do_log("File conversion process has ended.")


    # exports the converted data to file
    def btn_action_export_to_file(self, data, _path ):
        print ("btn_action_export_to_file")
        self.p_root.utility.do_log("File exporting process has started.")
        _f = filedialog.asksaveasfile(mode='w', initialdir = "/", initialfile=((_path.split("."))[0] + "_anonym.json"), defaultextension=".json", filetypes=(('JSON','.json'),))

        if _f is None:
            return

        with open(_f.name, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

        f.close() 

        self.p_root.utility.do_log("File exporting process has ended.")
        print ("btn_action_export_to_file - COMPLITED")


    #handles the file loading process locally
    def layout_file_load_action(self):
        if (self.p_root.data.isfileloaded):
            self.p_root.data.unload_file()
        self.p_root.data.load_file()


    #handles the file unloading process locally
    def layout_file_unload_action(self):
        if (self.p_root.data.isfileloaded):
            self.p_root.data.unload_file()
            self.update_ui_data()
            self.f_top_entry.delete(0,END)
            self.f_top_entry.insert(0,"")
            self.check_path_consistency("File has been successfully unloaded.")
        self.drew()


    # bottom entrybox value updater
    def update_ui_data(self):
        _m = ""
        if (self.p.p.data.isfileloaded):
            _m = self.p.p.data.file_path
        else:
            _m = " - no file has been loaded - "
        self.f_bottom_entry.config(state='normal')
        self.f_bottom_entry.delete(0, tk.END)
        self.f_bottom_entry.insert(0, _m)
        self.f_bottom_entry.config(state='disabled')
        self.fill_tree()


    # top notification label's updater, its about file loading process feedback
    def check_path_consistency(self, m=""):
        _p = self.f_top_entry.get()
        _m = m
        if (_m == ""):
            if (os.path.exists(_p)):
                _p_path, _p_ext = os.path.splitext(_p)
                if (_p_ext in [".json",".txt"]):
                    _m = ""
                else:
                    _m = "WARNING: Unexpected file extension. Supported extensions are: .json, .txt"
            else:
                _m = "ERROR: File does not exist"
        self.f_top_lb_note.config(text=_m)
        if (_m != ""):
            self.p.p.utility.do_log("RELAYING MESSAGE:  |  " + _m)


    #tree filling related IDs
    def get_iid(self):
        self.iid = self.iid + 1
        return self.iid


    #totally clearing a tree
    def clear_tree(self,v):
        for _i in v.get_children():
            v.delete(_i)


    # primitive way of filling the trees, this thing will be replaced anyway 
    def fill_tree(self):
        print("tree filling")
        self.iid = 10
        #tree
        self.clear_tree(self.tree)
        try:
            #_data_t_patient = self.p_root.data.get_data("PatientInformation")
            _data_t_patient = self.p_root.data.d["PatientInformation"]
            for _y in _data_t_patient:
                if (isinstance((_data_t_patient[_y]),(dict))):
                    new_folder = self.tree.insert("", 1, self.get_iid(), text=str(_y), open = True)
            
                    for _x in _data_t_patient[_y]:
                        _h = self.tree.insert(new_folder, "end", self.get_iid(), text=(str(_x)),open = True)
                        self.tree.insert(_h, "end", self.get_iid(), text=(str(_data_t_patient[_y].get(_x))),open = True)
        except Exception as _error_msg:
            print ("Exception reached: " + str(_error_msg))
        #tree2
        self.clear_tree(self.tree2)
        try:
            #_data_t_device = self.p_root.data.get_data("DeviceInformation")
            _data_t_device = self.p_root.data.d["DeviceInformation"]
            for _y in _data_t_device:
                if (isinstance((_data_t_device[_y]),(dict))):
                    new_folder = self.tree2.insert("", 1, self.get_iid(), text=str(_y), open = True)
            
                    for _x in _data_t_device[_y]:
                        _h = self.tree2.insert(new_folder, "end", self.get_iid(), text=(str(_x)),open = True)
                        self.tree2.insert(_h, "end", self.get_iid(), text=(str(_data_t_device[_y].get(_x))),open = True)
        except Exception as _error_msg:
            print ("Exception reached: " + str(_error_msg))


        self.clear_tree(self.tree3)

    # basic drawing function
    def drew(self):
        self.p.b_content_isloading = True
        print ("drawing : " + self.name)

        _f_main_x = self.frame_margin
        _f_main_y = self.frame_margin
        _f_main_w = self.p.canvas.winfo_width() - (self.frame_margin * 2)
        _f_main_h = self.p.canvas.winfo_height() - (self.frame_margin * 2)
        self.f_main.place(x = _f_main_x, y = _f_main_y, width= _f_main_w, height = _f_main_h)
        
        
        _f_top_x = self.frame_margin
        _f_top_y = self.frame_margin
        _f_top_w = _f_main_w - (self.frame_margin * 2)
        _f_top_h = (self.f_top_single_height * 3) + 1 + (self.frame_margin * 2)
        self.f_top.place(x = _f_top_x, y = _f_top_y, width= _f_top_w, height = _f_top_h)

        _f_line_top_x = self.frame_margin
        _f_line_top_y = self.frame_margin
        _f_line_top_w = _f_top_w - (self.frame_margin * 2)
        _f_line_top_h = _f_top_h - (self.frame_margin * 2)
        self.f_line_top.place(x = _f_line_top_x, y = _f_line_top_y, width= _f_line_top_w, height = _f_line_top_h)

        _f_top_label_h = self.f_top_single_height
        self.f_top_label.place(x = 0, y = 0, height = _f_top_label_h)

        _f_top_entry_y = _f_top_label_h + 1
        _f_top_entry_w = _f_line_top_w - self.f_top_btn_w - 10 - self.f_top_single_height - 10 - 200 - 10
        _f_top_entry_h = self.f_top_single_height
        self.f_top_entry.place(x = 0, y = _f_top_entry_y, width = _f_top_entry_w, height = _f_top_entry_h)

        self.f_top_button_browse.place(x= _f_top_entry_w + 10 , y= _f_top_entry_y, width= self.f_top_single_height , height= self.f_top_single_height)
        self.f_top_button_convert.place(x= _f_top_entry_w + 10 + self.f_top_single_height + 10 , y= _f_top_entry_y, width= 200 , height= self.f_top_single_height)
        self.f_top_button.place(x = _f_top_entry_w  + 10 + self.f_top_single_height + 10 + 200 + 10, y = _f_top_entry_y, width = self.f_top_btn_w - 10, height = _f_top_entry_h)
        print (str([self.p.canvas.winfo_width(), _f_main_w, _f_top_w]))

        _f_top_lb_note_x = 0
        _f_top_lb_note_y = _f_top_entry_y + _f_top_entry_h + 1
        #_f_top_lb_note_w = # there is no _w_ because it is not designed to have line wrap of anything similar
        # TODO : IN case if needed this needs to be modified to have lienwrap, but at this point the whole page should be reqritten dinamically
        _f_top_lb_note_h = self.f_top_single_height
        self.f_top_lb_note.place( x = _f_top_lb_note_x, y = _f_top_lb_note_y, height = _f_top_lb_note_h)

        _f_bottom_x = _f_top_x
        _f_bottom_y = _f_top_y + self.frame_spacing + _f_top_h
        _f_bottom_w = _f_main_w - (self.frame_margin * 2)
        _f_bottom_h = _f_main_h - _f_top_y - _f_top_h - (self.frame_margin * 1) - self.frame_spacing
        self.f_bottom.place(x = _f_bottom_x, y = _f_bottom_y, width= _f_bottom_w, height = _f_bottom_h)

        _f_line_x = self.frame_margin
        _f_line_y = self.frame_margin
        _f_line_w = _f_bottom_w - (self.frame_margin * 2)
        _f_line_h = (self.f_top_single_height * 2) + 1
        self.f_line.place(x = _f_line_x, y = _f_line_y, width= _f_line_w, height = _f_line_h)

        # second line starts here
        _f_bottom_label_h = self.f_top_single_height
        self.f_bottom_label.place(x = 0, y = 0, height = _f_bottom_label_h)

        _f_bottom_entry_y = _f_bottom_label_h + 1
        _f_bottom_entry_w = _f_line_w
        _f_bottom_entry_h = self.f_top_single_height
        self.f_bottom_entry.place(x = 0, y = _f_bottom_entry_y, width = _f_bottom_entry_w - (self.f_top_btn_w + 10), height = _f_bottom_entry_h)

        self.f_bottom_button.place(x = _f_top_entry_w  + 10 + self.f_top_single_height + 10 + 200 + 10, y = _f_bottom_entry_y, width = self.f_top_btn_w - 10, height = _f_bottom_entry_h)

        print (str([_f_line_x,_f_line_y,_f_line_w,_f_line_h]))
        _f_col_1_x = self.frame_margin
        _f_col_1_y = _f_line_y + self.frame_spacing + _f_line_h
        _f_col_1_w = ((_f_bottom_w - ((self.frame_margin * 2) + (self.frame_spacing * 2))) / 3)
        _f_col_1_h = _f_bottom_h - _f_line_h - (self.frame_margin * 1) - self.frame_spacing - _f_line_x
        self.f_col_1.place(x = _f_col_1_x, y = _f_col_1_y, width= _f_col_1_w, height = _f_col_1_h)

        _f_col_2_x = self.frame_margin + (self.frame_spacing * 1) + _f_col_1_w
        _f_col_2_y = _f_line_y + self.frame_spacing + _f_line_h
        _f_col_2_w = ((_f_bottom_w - ((self.frame_margin * 2) + (self.frame_spacing * 2))) / 3)
        _f_col_2_h = _f_bottom_h - _f_line_h - (self.frame_margin * 1) - self.frame_spacing - _f_line_x
        self.f_col_2.place(x = _f_col_2_x, y = _f_col_2_y, width= _f_col_2_w, height = _f_col_2_h)

        _f_col_3_x = self.frame_margin + (self.frame_spacing * 2)  + _f_col_1_w + _f_col_2_w
        _f_col_3_y = _f_line_y + self.frame_spacing + _f_line_h
        _f_col_3_w = ((_f_bottom_w - ((self.frame_margin * 2) + (self.frame_spacing * 2))) / 3)
        _f_col_3_h = _f_bottom_h - _f_line_h - (self.frame_margin * 1) - self.frame_spacing - _f_line_x
        self.f_col_3.place(x = _f_col_3_x, y = _f_col_3_y, width= _f_col_3_w, height = _f_col_3_h)

        #trees
        self.tree.place(x = _f_col_1_x, y = _f_col_1_y, width= _f_col_1_w, height = _f_col_1_h)
        self.tree2.place(x = _f_col_2_x, y = _f_col_2_y, width= _f_col_2_w, height = _f_col_2_h)
        self.tree3.place(x = _f_col_3_x, y = _f_col_3_y, width= _f_col_3_w, height = _f_col_3_h)

        self.f_main.update()
        self.f_top.update()
        self.p.b_content_isloading = False


    # In theory this is a working function, but not in use anymore, anyway kept here for the time being.
    # an updated verison of this function can be found in the file of layout_compare
    #def recursive_get(self, par, source):
    #    print (str(["recursive_get", par, source]))
    #    for i in source:
    #        print (str(i))
    #        print (str(source[i]))
    #        _i = source[i]
    #        if (isinstance(_i,list)):
    #            if (len(_i) > 0):
    #                print ("")
    #            #for ii in _i:
    #                if (isinstance(_i[0],dict)):
    #                    self.recursive_get(i, _i[0])
    #                else:
    #                    print ("3" + str(_i))
    #            else:
    #                print ("2" + str(_i))
    #        else:
    #            print ("1" + str(_i))