
#general
import string
import random
import json
import os
import numpy as np
import subprocess
import math

#datetime for date realted operations
import datetime
from datetime import date
from datetime import timedelta
from dateutil import parser

#tkinter for UI
from tkinter import *
import tkinter as tk
from tkinter import ttk
from tkinter import filedialog
from tkinter.font import Font

#matplotlib for the figure stuffs
import matplotlib
matplotlib.use("Agg") # was modified from "TkAgg" to "Agg" , because the window close x button have closed windows in the wrong order and the app was just hanging there.
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.cbook as cbook
import matplotlib.patches as mpatches
from matplotlib import pylab

#for taking screenshot of the app
import PIL.Image as Image
import PIL.ImageTk as ImageTk
import PIL.ImageGrab as ImageGrab
from PIL import Image, ImageTk



import datetime
import pytz

utc=pytz.UTC

from matplotlib.ticker import FormatStrFormatter
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator


import os.path
from datetime import datetime

import tkinter.font as tkfont

import textwrap

import matplotlib.pyplot as plt
import matplotlib.patches as patches


import gc



print ("IMPORTING - layout_data.py")

#other
from src.modules import _layout as _layout


### CODE

# NOTE : There is a chance of a very tiny memory leak being somewhere, but even that is unlikely after a couple of tests. Memory usage usually stays around 100Mb, based on which layout is loaded at the time.
class ui_layout_data(_layout.layout_base):
    def __init__(self, parent, root):
        self._cfg_layout = {
            "parent": parent,
            "p_root": root,
            "name": "ui_layout_data",
            "name_simple": "data"
            }
        super().__init__(self._cfg_layout)

        self.color = "white"
        self.frame_margin = 10
        self.frame_spacing = 10
        self.f_btn_height = 30      # toolbar button height
        self.slider_height = 60     # top graph for slider height
        self.graph_margin = [75,60,1,25]    #left/right/top/bottom

        self.f_disp_setting_w_shrinked = 0
        self.f_disp_setting_w_extended = 200
        self.f_disp_setting_isshrinked = False


        # TODO : Fine tune the "graph loading" message with font, size, etc...      ( I do not even know what this means )
        self.f_main = Frame(self.p.canvas, name="f_main", bg="white")
        self.f_btn = Frame(self.f_main, name="f_btn", bg="white", highlightthickness = 1 , bd = 1, highlightcolor = "grey")

        #Toolbar configuration
        self.tb_margin = 1
        self.tb_spacing = 1
        self.tb_lb1 = Label(self.f_btn, text ="From:", bg = "white")
        self.tb_e1 = Entry(self.f_btn, relief='ridge', highlightthickness = 1 , bd = 1, highlightcolor = "grey" )
        self.tb_lb2 = Label(self.f_btn, text ="To:", bg = "white")
        self.tb_e2 = Entry(self.f_btn, relief='ridge', highlightthickness = 1 , bd = 1, highlightcolor = "grey" )
        self.tb_b1 = Button(self.f_btn, text ="|->", command = lambda: self.tb_btn_action("|->"))
        self.tb_b2 = Button(self.f_btn, text ="<<", command = lambda: self.tb_btn_action("<<"))
        self.tb_b3 = Button(self.f_btn, text =">>", command = lambda: self.tb_btn_action(">>"))
        self.tb_b4 = Button(self.f_btn, text ="1", command = lambda: self.tb_btn_action("1"))
        self.tb_b5 = Button(self.f_btn, text ="3", command = lambda: self.tb_btn_action("3"))
        self.tb_b6 = Button(self.f_btn, text ="7", command = lambda: self.tb_btn_action("7"))
        self.tb_b7 = Button(self.f_btn, text ="30", command = lambda: self.tb_btn_action("30"))
        self.tb_b11 = Button(self.f_btn, text ="All", command = lambda: self.tb_btn_action("all"))
        self.tb_b14 = Button(self.f_btn, text ="|", command = lambda: self.tb_btn_action("all"), bg = "white", state = DISABLED, relief='flat')
        self.tb_b8 = Button(self.f_btn, text ="Filter", command = lambda: self.tb_btn_action("filter"))
        self.tb_b9 = Button(self.f_btn, text ="SnapShot", command = lambda: self.tb_btn_action("snapshot"))
        self.tb_b10 = Button(self.f_btn, text ="Reload", command = lambda: self.tb_btn_action("reload"))
        self.tb_b12 = Button(self.f_btn, text ="Test", command = lambda: self.tb_btn_action("test"))
        self.tb_b15 = Button(self.f_btn, text ="|", command = lambda: self.tb_btn_action("all"), bg = "white", state = DISABLED, relief='flat')
        self.tb_lb3 = Label(self.f_btn, text ="LFP upper limit:", bg = "white")
        self.tb_e3 = Entry(self.f_btn, relief='ridge', highlightthickness = 1 , bd = 1, highlightcolor = "grey" )
        self.tb_b13 = Button(self.f_btn, text ="<-| Set LFP Lim.", command = lambda: self.tb_btn_action("set_lfp_lim"))

        self.tb_holder= [[self.tb_lb1,-99],
                         [self.tb_e1,100],
                         [self.tb_lb2,-99],
                         [self.tb_e2,100],
                         [self.tb_b1,-1],
                         [self.tb_b2,-1],
                         [self.tb_b3,-1],
                         [self.tb_b4,-1],
                         [self.tb_b5,-1],
                         [self.tb_b6,-1],
                         [self.tb_b7,-1],
                         [self.tb_b11,-1],
                         [self.tb_b14,10],
                         [self.tb_b8,70],
                         [self.tb_b9,70],
                         [self.tb_b10,70],
                         [self.tb_b12,70],
                         [self.tb_b15,10],
                         [self.tb_lb3,-99],
                         [self.tb_e3, 70],
                         [self.tb_b13,100]]

        #other UI definitions
        #graphs
        self.f_slider = Label(self.f_main, name="f_slider", bg="red", text="Graph Loading...")
        self.f_graph1 = Label(self.f_main, name="f_graph1", bg="pink", text="Graph Loading...")
        self.f_graph2 = Label(self.f_main, name="f_graph2", bg="yellow", text="Graph Loading...")

        #display sidemenu
        self.f_disp_setting = Frame(self.f_main, name="f_disp_setting", bg="gainsboro")
        self.f_disp_main = Frame(self.f_disp_setting, name="f_disp_main", bg="grey95")
        self.f_disp_lb = Label(self.f_disp_main, name="f_disp_lb", bg="tan1", text="Display Settings", anchor="center", fg="black")
        self.f_disp_sub = Frame(self.f_disp_main, name="f_disp_sub", bg="grey95")

        #snapshot sidemenu
        self.f_snaps_viewer = Frame(self.f_main, name="f_snaps_viewer", bg="gainsboro")
        self.f_snaps_main = Frame(self.f_snaps_viewer, name="f_snaps_main", bg="white") # bg="grey95"
        self.f_snaps_lb_height = 40 
        self.f_snaps_lb = Label(self.f_snaps_main, name="f_snaps_lb", bg="tan1", text="SnapShot Viewer", anchor="center", fg="black")
        self.f_snaps_sub = Frame(self.f_snaps_main, name="f_snaps_sub", bg="grey95")
        self.f_snap_listbox = Listbox(self.f_snaps_main, name="f_snap_listbox" , bg = "tan1", selectmode = tk.SINGLE)
        self.f_snap_listbox_scrollbar = Scrollbar(self.f_snaps_main, orient='vertical', command=self.f_snap_listbox.yview)
        self.f_snap_listbox.config(yscrollcommand=self.f_snap_listbox_scrollbar.set)
        self.f_snap_listbox.bind("<<ListboxSelect>>", self.snaps_listbox_sel_change_action)


        #listing all the available plots (lines, that were previously added with set_data())
        self.holder_disp_options = []
        for _gx in [self.p.graph_1, self.p.graph_2]:
            _gx_r = [_gx.config_[0][1],[]]
            for _gx_ in _gx.holder_plots:
                if (_gx_.isdisplayable):
                    _gx_r[1].append(_gx_.name)
            self.holder_disp_options.append(_gx_r)


        # generates the structure of the display sidemenu, based on how many type of events (plots) there are
        # NOTE : I don't fully understand this function, but it does works well, so it stays like this 
        self.btn_w = 30 # not in use for some reasons
        self.btn_h = 30
        self.btn_space = 1
        self.holder_disp_objs = []
        self.holder_i = 0
        for _gyi in range(0,len(self.holder_disp_options)):
            _gy = self.holder_disp_options[_gyi]
            _gy_name = _gy[0]
            #create the option base Uis
            _gy_loc = ui_f_disps(self, self.f_disp_sub, [_gy_name, 0, _gy_name, [], [0,(0 + (self.holder_i * (self.btn_h + self.btn_space))),self.f_disp_setting_w_extended - (self.frame_margin) ,self.btn_h]])
            self.holder_disp_objs.append(_gy_loc)
            self.holder_i = self.holder_i + 1
            #creates the option UIs
            for _gyii in range(0,len(_gy[1])):
                _gy__ = _gy[1][_gyii]
                _gy_ = ui_f_disps(self, self.f_disp_sub, [_gy_name + "_" +_gy__, 1, _gy__, [[0,0,0,0],[[(_gy__),"lime green","ON",True,_gy_name], [(_gy__),"firebrick2","OFF",False,_gy_name]],True], [0,(0 + (self.holder_i * (self.btn_h + self.btn_space))),self.f_disp_setting_w_extended - (self.frame_margin),self.btn_h]])
                self.holder_disp_objs.append(_gy_)
                self.holder_i = self.holder_i + 1


    # snapshot sidemenu's listbox selection action ( basically loads data to SS graph )
    def snaps_listbox_sel_change_action(self, event):
        if (len(self.f_snap_listbox.curselection()) > 0):
            _b = False
            #_l_m = self.p.p.root.p.data.dd_ss_cur[(self.f_snap_listbox.curselection()[0]) - 1]["LfpFrequencySnapshotEvents"]
            try:
                _x = self.f_snap_listbox.curselection()[0]
                
                if ((_x > 0) and ((len(self.p.p.root.p.data.dd_ss_cur)) > 0)):
                    if ("LfpFrequencySnapshotEvents" in self.p.p.root.p.data.dd_ss_cur[_x - 1]):    # this was not here previously, but for some reason dict reaching stoppedthrowing proper exception
                        _l_m = self.p.p.root.p.data.dd_ss_cur[_x - 1]["LfpFrequencySnapshotEvents"]["HemisphereLocationDef.Left"]["FFTBinData"]
                        _l_f = self.p.p.root.p.data.dd_ss_cur[_x - 1]["LfpFrequencySnapshotEvents"]["HemisphereLocationDef.Left"]["Frequency"]

                        _r_m = self.p.p.root.p.data.dd_ss_cur[_x - 1]["LfpFrequencySnapshotEvents"]["HemisphereLocationDef.Right"]["FFTBinData"]
                        _r_f = self.p.p.root.p.data.dd_ss_cur[_x - 1]["LfpFrequencySnapshotEvents"]["HemisphereLocationDef.Right"]["Frequency"]

                        self.p.graph_ss.set_data("Hem.Left", _l_f, _l_m, True)
                        self.p.graph_ss.set_data("Hem.Right", _r_f, _r_m, True)

                        _g_ = self.p.graph_ss
                        for _g__ in _g_.holder_plots:
                            _g__.b_changed_settings = True
                            _g__.b_changed_data = True
                        _g_.holder_subplot[0].autoscale(True,"both",True)

                        self.p.graph_ss._place()
                        self.p.canv_graph_ss.update()
                        print ("Snapshot data has been loaded successfully.")
                    else:
                        print ("No visualisable data belongs to this entry.")
                        _b = True
                else:
                    _b = True
            except Exception  as _error_msg:
                self.p.p.utility.do_log ("ERROR : Was not able to load SnapShot data to graph.  |  " + str(_error_msg))
                _b = True

            # in case if something gone wrogne, load default nothingless
            if (_b):
                self.p.graph_ss.set_data("Hem.Left", [], [], True)
                self.p.graph_ss.set_data("Hem.Right", [], [], True)

                _g_ = self.p.graph_ss
                for _g__ in _g_.holder_plots:
                    _g__.b_changed_settings = True
                    _g__.b_changed_data = True
                _g_.holder_subplot[0].autoscale(True,"both",True)

                self.p.graph_ss._place()
                self.p.canv_graph_ss.update()
        else:
            self.p.p.utility.do_log ("ERROR : Wrong input field in the listbox, please report this to the developer. Function: -snaps_listbox_sel_change_action-")

        
    #does the top graph's rectangle ( the hightlight ) related action 
    def rectangle_action(self):
        #currently there is only one patch, but I used for anyway
        for _p in self.p.graph_0.fig.patches:
            if (_p == self.p._rect_patch):
                #graph margin rel float numbers from params
                _x = self.p.graph_0.fig.subplotpars.left
                _y = self.p.graph_0.fig.subplotpars.bottom
                _wm = (1 - self.p.graph_0.fig.subplotpars.left - (1 - self.p.graph_0.fig.subplotpars.right))
                _hm = (1 - self.p.graph_0.fig.subplotpars.bottom - (1 - self.p.graph_0.fig.subplotpars.top))

                # get date based relativity
                _interval_all = (self.p.p.root.p.data.date_max_lim - self.p.p.root.p.data.date_min_lim).total_seconds()

                #calculating new positions
                _x_fin = _x +  (_wm * ((self.p.p.root.p.data.date_min_cur - self.p.p.root.p.data.date_min_lim).total_seconds() / _interval_all ))
                _y_fin = _y
                _w_fin = (_wm * ((self.p.p.root.p.data.date_max_cur - self.p.p.root.p.data.date_min_cur).total_seconds() / _interval_all))
                _h_fin = _hm

                #committing  new position
                _p.set_xy((_x_fin,_y_fin))
                _p.set_width(_w_fin)
                _p.set_height(_h_fin)
        self.p.graph_0.fig.canvas.draw()


    #toolbar action list
    def tb_btn_action(self, b):
        print ("Executing function: -tb_btn_action- | with parameter: " + str(b))
        if ( b == "1" ):
            print (b)
            if (self.p.p.root.p.data.date_interval_lim > 1):
                self.p.p.root.p.data.date_interval_cur = 1
                # allign to MIN
                #self.date_correction_to_boundary((self.p.p.root.p.data.date_min_cur), (self.p.p.root.p.data.date_min_cur + timedelta(days=self.p.p.root.p.data.date_interval_cur)), self.p.p.root.p.data.date_interval_cur)
                # allign to MAX
                self.date_correction_to_boundary((self.p.p.root.p.data.date_max_cur - timedelta(days=self.p.p.root.p.data.date_interval_cur)), self.p.p.root.p.data.date_max_cur, self.p.p.root.p.data.date_interval_cur)
                self.tb_btn_action("reload")
            else:
                self.tb_btn_action("all")
        elif ( b == "3"):
            print (b)
            if (self.p.p.root.p.data.date_interval_lim > 3):
                self.p.p.root.p.data.date_interval_cur = 3
                # allign to MIN
                #self.date_correction_to_boundary((self.p.p.root.p.data.date_min_cur), (self.p.p.root.p.data.date_min_cur + timedelta(days=self.p.p.root.p.data.date_interval_cur)), self.p.p.root.p.data.date_interval_cur)
                # allign to MAX
                self.date_correction_to_boundary((self.p.p.root.p.data.date_max_cur - timedelta(days=self.p.p.root.p.data.date_interval_cur)), self.p.p.root.p.data.date_max_cur, self.p.p.root.p.data.date_interval_cur)
                self.tb_btn_action("reload")
            else:
                self.tb_btn_action("all")
        elif ( b == "7"):
            print (b)
            if (self.p.p.root.p.data.date_interval_lim > 7):
                self.p.p.root.p.data.date_interval_cur = 7
                # allign to MIN
                #self.date_correction_to_boundary((self.p.p.root.p.data.date_min_cur), (self.p.p.root.p.data.date_min_cur + timedelta(days=self.p.p.root.p.data.date_interval_cur)), self.p.p.root.p.data.date_interval_cur)
                # allign to MAX
                self.date_correction_to_boundary((self.p.p.root.p.data.date_max_cur - timedelta(days=self.p.p.root.p.data.date_interval_cur)), self.p.p.root.p.data.date_max_cur, self.p.p.root.p.data.date_interval_cur)
                self.tb_btn_action("reload")
            else:
                self.tb_btn_action("all")
            
        elif ( b == "30"):
            print (b)
            if (self.p.p.root.p.data.date_interval_lim > 30):
                self.p.p.root.p.data.date_interval_cur = 30
                # allign to MIN
                #self.date_correction_to_boundary((self.p.p.root.p.data.date_min_cur), (self.p.p.root.p.data.date_min_cur + timedelta(days=self.p.p.root.p.data.date_interval_cur)), self.p.p.root.p.data.date_interval_cur)
                # allign to MAX
                self.date_correction_to_boundary((self.p.p.root.p.data.date_max_cur - timedelta(days=self.p.p.root.p.data.date_interval_cur)), self.p.p.root.p.data.date_max_cur, self.p.p.root.p.data.date_interval_cur)
                self.tb_btn_action("reload")
            else:
                self.tb_btn_action("all")
        elif ( b == "all"):
            print (b)
            self.p.p.root.p.data.date_min_cur = self.p.p.root.p.data.date_min_lim
            self.p.p.root.p.data.date_max_cur = self.p.p.root.p.data.date_max_lim
            self.p.p.root.p.data.date_interval_cur = self.p.p.data.calc_date_interval_general(self.p.p.root.p.data.date_min_cur, self.p.p.root.p.data.date_max_cur)
            self.tb_btn_action("reload")
        elif ( b == "|->"):
            _min = self.tb_e1.get()
            _max = self.tb_e2.get()
            _min_d = None
            _max_d = None
            _b = True
            if (self.check_date_input_validity(_min)):
                _min_d = self.covert_date_input_to_date(self.get_date_input_array(_min), True)
                if (_min_d == None):
                    self.p.p.utility.do_log("ERROR : Toolbar action -|->- encountered an error. Function -covert_date_input_to_date- returned value: None")
                    _b = False
            else:
                self.p.p.utility.do_log("ERROR : Toolbar action -|->- encountered an error. Minimum input value is invalid, or does not match the formating requirement ( yyyy.mm.dd | yyyy.mm.d | yyyy.m.d | yyyy.m.dd )")
                _b = False
            if (self.check_date_input_validity(_max)):
                _max_d = self.covert_date_input_to_date(self.get_date_input_array(_max), False)
                if (_max_d == None):
                    self.p.p.utility.do_log("ERROR : Toolbar action -|->- encountered an error. Function -covert_date_input_to_date- returned value: None")
                    _b = False
            else:
                self.p.p.utility.do_log("ERROR : Toolbar action -|->- encountered an error. Maximum input value is invalid, or does not match the formating requirement ( yyyy.mm.dd | yyyy.mm.d | yyyy.m.d | yyyy.m.dd )")
                _b = False

            if (_b):
                if (_min_d > _max_d):
                    self.p.p.utility.do_log("ERROR : Toolbar action -|->- encountered an error. Wrong order of dates. Minimal date is larger than the maximum.")
                    _b = False
                if (_min_d < self.p.p.root.p.data.date_min_lim):
                    self.p.p.utility.do_log("ERROR : Toolbar action -|->- encountered an error. Minimum date is out of boundary.")
                    _b = False
                if (_max_d > self.p.p.root.p.data.date_max_lim):
                    self.p.p.utility.do_log("ERROR : Toolbar action -|->- encountered an error. Maximum date is out of boundary.")
                    _b = False
                    
            #committing changes
            if (_b):
                self.p.p.root.p.data.date_min_cur = _min_d
                self.p.p.root.p.data.date_max_cur =_max_d
                self.p.p.root.p.data.date_interval_cur = self.p.p.data.calc_date_interval_general(self.p.p.root.p.data.date_min_cur, self.p.p.root.p.data.date_max_cur)
                self.tb_btn_action("reload")
            else:
                self.p.p.utility.do_log("ERROR : Toolbar action -|->- failed to execute properly. Something went wrong.")
        elif ( b == "<<"):
            self.date_correction_to_boundary((self.p.p.root.p.data.date_min_cur - timedelta(days=self.p.p.root.p.data.date_interval_cur)), (self.p.p.root.p.data.date_max_cur - timedelta(days=self.p.p.root.p.data.date_interval_cur)), self.p.p.root.p.data.date_interval_cur)
            self.tb_btn_action("reload")
        elif ( b == ">>"):
            self.date_correction_to_boundary((self.p.p.root.p.data.date_min_cur + timedelta(days=self.p.p.root.p.data.date_interval_cur)), (self.p.p.root.p.data.date_max_cur + timedelta(days=self.p.p.root.p.data.date_interval_cur)), self.p.p.root.p.data.date_interval_cur)
            self.tb_btn_action("reload")
        elif (b == "filter"):
            print (b)
            if (self.p.p.root.p.settings.data_view_filter_is_shrinked):
                self.p.p.root.p.settings.data_view_snapshot_is_shrinked = True
                self.p.p.root.p.settings.data_view_filter_is_shrinked = False
            else:
                self.p.p.root.p.settings.data_view_snapshot_is_shrinked = True
                self.p.p.root.p.settings.data_view_filter_is_shrinked = True
            self.drew()
        elif (b == "snapshot"):
            print (b)
            if (self.p.p.root.p.settings.data_view_snapshot_is_shrinked):
                self.p.p.root.p.settings.data_view_snapshot_is_shrinked = False
                self.p.p.root.p.settings.data_view_filter_is_shrinked = True
            else:
                self.p.p.root.p.settings.data_view_snapshot_is_shrinked = True
                self.p.p.root.p.settings.data_view_filter_is_shrinked = True
            self.drew()
        elif (b == "reload"):
            self.drew()
        elif (b == "test"):
            #self.construct_lims()
            #self.p.p.root.p.data.construct_lims()
            self.p.p.utility.do_log("ERROR : Toolbar action -test- failed to execute properly. Reserverd for testing, no action being executed at the moment")
        elif (b == "set_lfp_lim"):
            _lfp_lim_new = self.tb_e3.get()
            if (_lfp_lim_new.isdigit()):
                _lfp_lim_new = int(_lfp_lim_new)
                self.p.p.root.p.data.lfp_max_displayable_value = _lfp_lim_new
                self.tb_btn_action("reload")
            else:
                self.p.p.utility.do_log("ERROR : Toolbar action -set_lfp_lim- failed to execute properly. Input value is not numerical or not correctly formated.")
        else:
            self.p.p.utility.do_log("ERROR : Toolbar action -?- failed to execute properly. Possible incorrect action code : " + str(b))



    # Corrects the given date to the min-max limits, while keeping the interval value the same. 
    def date_correction_to_boundary(self, min_d , max_d, range_d):
        _min_d = min_d
        _max_d = max_d
        if ((min_d < self.p.p.root.p.data.date_min_lim) or (max_d > self.p.p.root.p.data.date_max_lim)):
            if (min_d < self.p.p.root.p.data.date_min_lim):
                _min_d = self.p.p.root.p.data.date_min_lim
                _max_d = _min_d + timedelta(days=range_d)
            if (max_d > self.p.p.root.p.data.date_max_lim):
                _max_d = self.p.p.root.p.data.date_max_lim
                _min_d = _max_d - timedelta(days=range_d)
        self.p.p.root.p.data.date_min_cur = _min_d
        self.p.p.root.p.data.date_max_cur = _max_d
        self.p.p.root.p.data.date_interval_cur = range_d


    # Check if the given input is a correctly formated date ( yyyy.mm.dd | yyyy.mm.d | yyyy.m.d | yyyy.m.dd )
    # NOTE : There could be a built in function to determine if a value is correct date or not, but I just wrote this one for myself.
    # The value 3000 is represents the "year" limitation
    def check_date_input_validity(self, s):
        _len_s = len(s)
        if (_len_s > 7) and (_len_s < 11):
            if (_len_s == 10):
                if (s[0:4].isdigit() and s[5:7].isdigit() and s[8:10].isdigit()):
                    if (( ((int(s[0:4])) > 0) and ((int(s[0:4])) < 3000) ) and ( ((int(s[5:7])) > 0) and ((int(s[5:7])) < 13) ) and ( ((int(s[8:10])) > 0) and ((int(s[8:10])) < 32) )):
                        return True
            if (_len_s == 9):
                if (s[5:7].isdigit()):
                    if (s[0:4].isdigit() and s[5:7].isdigit() and s[8:9].isdigit()):
                        if (( ((int(s[0:4])) > 0) and ((int(s[0:4])) < 3000) ) and ( ((int(s[5:7])) > 0) and ((int(s[5:7])) < 13) ) and ( ((int(s[8:9])) > 0) and ((int(s[8:9])) < 32) )):
                            return True
                else:
                    if (s[0:4].isdigit() and s[5:6].isdigit() and s[7:9].isdigit()):
                        if (( ((int(s[0:4])) > 0) and ((int(s[0:4])) < 3000) ) and ( ((int(s[5:6])) > 0) and ((int(s[5:6])) < 13) ) and ( ((int(s[7:9])) > 0) and ((int(s[7:9])) < 32) )):
                            return True
            if (_len_s == 8):
                if (s[0:4].isdigit() and s[5:6].isdigit() and s[7:8].isdigit()):
                    if (( ((int(s[0:4])) > 0) and ((int(s[0:4])) < 3000) ) and ( ((int(s[5:6])) > 0) and ((int(s[5:6])) < 13) ) and ( ((int(s[7:8])) > 0) and ((int(s[7:8])) < 32) )):
                        return True
        return False


    # correct invalid date values and returns a valid floored version of that date
    # This only corrects invalid 31 days and February, based on date. If the input has other invalid digits, it will be caught before that by validity checker.
    def input_date_correction(self, a):
        _ret = a
        if (_ret[2] == 31):
            if not (_ret[1] in [1,3,5,7,8,10,12]):
                _ret[2] = 30
        if (_ret[2] == 30):
            if (_ret[1] in [2]):
                _ret[2] = 29
        if (_ret[2] == 29):
            if (_ret[1] in [2]):
                if not ((_ret[0] % 4) == 0):
                    _ret[2] = 28
        return _ret
            

    #prepare the correct, but raw input to processing into a date
    def get_date_input_array(self, s):
        _len_s = len(s)
        _ret = None
        if (_len_s == 10):
            if (s[0:4].isdigit() and s[5:7].isdigit() and s[8:10].isdigit()):
                if (( ((int(s[0:4])) > 0) and ((int(s[0:4])) < 3000) ) and ( ((int(s[5:7])) > 0) and ((int(s[5:7])) < 13) ) and ( ((int(s[8:10])) > 0) and ((int(s[8:10])) < 32) )):
                    _ret = self.input_date_correction([int(s[0:4]),  int(s[5:7]), int(s[8:10])])
        if (_len_s == 9):
            if (s[5:7].isdigit()):
                if (s[0:4].isdigit() and s[5:7].isdigit() and s[8:9].isdigit()):
                    if (( ((int(s[0:4])) > 0) and ((int(s[0:4])) < 3000) ) and ( ((int(s[5:7])) > 0) and ((int(s[5:7])) < 13) ) and ( ((int(s[8:9])) > 0) and ((int(s[8:9])) < 32) )):
                        _ret = self.input_date_correction([int(s[0:4]),  int(s[5:7]), int(s[8:9])])
            else:
                if (s[0:4].isdigit() and s[5:6].isdigit() and s[7:9].isdigit()):
                    if (( ((int(s[0:4])) > 0) and ((int(s[0:4])) < 3000) ) and ( ((int(s[5:6])) > 0) and ((int(s[5:6])) < 13) ) and ( ((int(s[7:9])) > 0) and ((int(s[7:9])) < 32) )):
                        _ret = self.input_date_correction([int(s[0:4]),  int(s[5:6]), int(s[7:9])])
        if (_len_s == 8):
            if (s[0:4].isdigit() and s[5:6].isdigit() and s[7:8].isdigit()):
                if (( ((int(s[0:4])) > 0) and ((int(s[0:4])) < 3000) ) and ( ((int(s[5:6])) > 0) and ((int(s[5:6])) < 13) ) and ( ((int(s[7:8])) > 0) and ((int(s[7:8])) < 32) )):
                    _ret = self.input_date_correction([int(s[0:4]),  int(s[5:6]), int(s[7:8])])
        return _ret
        

    # convcert the valid date array into proper date format
    def covert_date_input_to_date(self, a, b):
        _base = self.p.p.root.p.data.date_min_lim
        try:
            if (b):
                _base = _base.replace(year = a[0], month = a[1], day = a[2], hour = 0, minute = 0, second = 0)
            else:
                _base = _base.replace(year = a[0], month = a[1], day = a[2], hour = 23, minute = 59, second = 59)
        except:
            _base = None
        return _base


    # draw an stuffs 
    def drew(self):
        self.p.b_content_isloading = True
        print ("drawing : " + self.name)

        #???
        print ("1--------------------------------- " + str(datetime.now()))


        self.p.canvas.update_idletasks()
        #main frame
        _f_main_x = self.frame_margin
        _f_main_y = self.frame_margin
        _f_main_w = self.p.canvas.winfo_width() - (self.frame_margin * 2)
        _f_main_h = self.p.canvas.winfo_height() - (self.frame_margin * 2)
        self.f_main.place(x = _f_main_x, y = _f_main_y, width = _f_main_w , height = _f_main_h)

        #top button line
        _f_btn_x = self.frame_margin
        _f_btn_y = self.frame_margin
        _f_btn_w = _f_main_w - (self.frame_margin * 2)
        _f_btn_h = self.f_btn_height
        self.f_btn.place(x = _f_btn_x, y = _f_btn_y, width = _f_btn_w , height = _f_btn_h)


        #toolbar eleent placing and stuffs
        _i_loc = 0
        for _i in self.tb_holder:
            _w = _i[1]
            if (_w == -1):
                _w = _f_btn_h 
            elif (_w == -99):
                _w = _i[0].winfo_reqwidth()
            _i[0].place(x = _i_loc + self.tb_spacing, y = self.tb_margin, width = _w - 5, height = _f_btn_h - 5)
            _i_loc = _i_loc + _w + self.btn_space

        #entry - from - set-value
        self.tb_e1.delete(0, tk.END)
        _e1_text = ""
        if (isinstance(self.p.p.root.p.data.date_min_cur, int)):
            _e1_text = ""
        else:
            _e1_text = str(self.p.p.root.p.data.date_min_cur.strftime("%Y.%m.%d"))
        self.tb_e1.insert(0, _e1_text)

        #entry - to - set-value
        self.tb_e2.delete(0, tk.END)
        _e2_text = ""
        if (isinstance(self.p.p.root.p.data.date_max_cur, int)):
            _e2_text = ""
        else:
            _e2_text = str(self.p.p.root.p.data.date_max_cur.strftime("%Y.%m.%d"))
        self.tb_e2.insert(0, _e2_text)


        # sidemenu stuffs
        # NOTE : Its a bit weird that some value is stored in the -settings- class, but whatever
        # TODO : Some variable names (like: _f_disp_setting_w_cur) refer to _dispplay sidemenu, but its not display related, ust universal. These names may need to be renamed to avoid confusion.
        _f_disp_setting_w_cur = self.f_disp_setting_w_shrinked
        if not (self.p.p.root.p.settings.data_view_filter_is_shrinked):
            _f_disp_setting_w_cur = self.f_disp_setting_w_extended

        # TODO : SnapShot size needs better calculation
        if not (self.p.p.root.p.settings.data_view_snapshot_is_shrinked):
            _f_disp_setting_w_cur = int(_f_main_w * 0.3)

        # calc. coordinates
        _f_disp_setting_x = _f_main_w - self.frame_margin - _f_disp_setting_w_cur
        _f_disp_setting_y = _f_btn_y + _f_btn_h + self.frame_spacing
        _f_disp_setting_w = _f_disp_setting_w_cur
        _f_disp_setting_h = _f_main_h - _f_disp_setting_y - self.frame_margin

        #placing filter menu
        if not (self.p.p.root.p.settings.data_view_filter_is_shrinked):
            self.f_disp_setting.place(x = _f_disp_setting_x, y = _f_disp_setting_y, width = _f_disp_setting_w , height = _f_disp_setting_h)

            #setting main
            _f_disp_main_x = self.frame_margin /2
            _f_disp_main_y = self.frame_margin /2
            _f_disp_main_w = _f_disp_setting_w - (self.frame_margin)
            _f_disp_main_h = _f_disp_setting_h - (self.frame_margin)
            self.f_disp_main.place(x = _f_disp_main_x, y = _f_disp_main_y, width = _f_disp_main_w , height = _f_disp_main_h)

            #setting label
            _f_disp_lb_x = 0
            _f_disp_lb_y = 0
            _f_disp_lb_w = _f_disp_main_w
            _f_disp_lb_h = 50
            self.f_disp_lb.place(x = _f_disp_lb_x, y = _f_disp_lb_y, width = _f_disp_lb_w , height = _f_disp_lb_h)

            #setting sub
            _f_disp_sub_x = _f_disp_lb_x
            _f_disp_sub_y = _f_disp_lb_h + self.frame_spacing
            _f_disp_sub_w = _f_disp_lb_w
            _f_disp_sub_h = _f_disp_main_h - (_f_disp_lb_h + (self.frame_spacing))
            self.f_disp_sub.place(x = _f_disp_sub_x, y = _f_disp_sub_y, width = _f_disp_sub_w , height = _f_disp_sub_h)

            for _xplots_i in range(0,len(self.holder_disp_objs)):
                _xplots = self.holder_disp_objs[_xplots_i]
                _h = (_f_disp_sub_h / ( len(self.holder_disp_objs)))
                _xplots.y =  _xplots_i * (_h)
                _xplots.h = _h - self.btn_space
                if (_xplots.btn != ""):
                    _xplots.btn.w = _xplots.h - self.btn_space
                    _xplots.btn.h = _xplots.h - self.btn_space
                    _xplots.btn.x = _f_disp_sub_w - _xplots.h
                _xplots.draw()
        else:
            self.f_disp_setting.place_forget()

        #placing snapshot menu
        if not (self.p.p.root.p.settings.data_view_snapshot_is_shrinked):
            self.f_snaps_viewer.place(x = _f_disp_setting_x, y = _f_disp_setting_y, width = _f_disp_setting_w , height = _f_disp_setting_h)
            self.f_snaps_main.place(x = int(self.frame_margin / 2) , y = int(self.frame_margin / 2), width = _f_disp_setting_w - (1 * self.frame_margin), height = _f_disp_setting_h - (1 * self.frame_margin))
            self.f_snaps_lb.place(x = 0 , y = 0, width = _f_disp_setting_w - (1 * self.frame_margin), height = self.f_snaps_lb_height) #height = self.f_snaps_lb.winfo_reqheight()
        else:
            self.f_snaps_viewer.place_forget()
        

        #placing the frames that are under the graphs
        #slider, top graph_0 to overview content
        _f_slider_x = self.frame_margin
        _f_slider_y = _f_btn_y + _f_btn_h + self.frame_spacing
        _f_slider_w = _f_main_w - (self.frame_margin * 2) - _f_disp_setting_w_cur - self.frame_spacing
        _f_slider_h = self.slider_height + (self.frame_margin * 2)
        self.f_slider.place(x = _f_slider_x, y = _f_slider_y, width = _f_slider_w , height = _f_slider_h)

        #graph_1
        _f_graph1_x = self.frame_margin
        _f_graph1_y = _f_slider_y + _f_slider_h + self.frame_spacing
        _f_graph1_w = _f_slider_w #_f_main_w - (self.frame_margin * 2) - _f_disp_setting_w_cur - self.frame_spacing
        _f_graph1_h = (_f_main_h - (_f_graph1_y + (self.frame_spacing) + self.frame_margin)) / 2
        self.f_graph1.place(x = _f_graph1_x, y = _f_graph1_y, width = _f_graph1_w , height = _f_graph1_h)

        #graph_2
        _f_graph2_x = self.frame_margin
        _f_graph2_y = _f_graph1_y + _f_graph1_h + self.frame_spacing
        _f_graph2_w = _f_slider_w #_f_main_w - (self.frame_margin * 2) - _f_disp_setting_w_cur - self.frame_spacing
        _f_graph2_h = _f_graph1_h
        self.f_graph2.place(x = _f_graph2_x, y = _f_graph2_y, width = _f_graph2_w , height = _f_graph2_h)

        #graph_0
        #_f_graph2_x = self.frame_margin
        #_f_graph2_y = _f_graph1_y + _f_graph1_h + self.frame_spacing
        _f_graph0_w = _f_main_w - (self.frame_margin * 2) - _f_disp_setting_w_cur - self.frame_spacing
        #_f_graph2_h = _f_graph1_h
        #self.f_graph2.place(x = _f_graph2_x, y = _f_graph2_y, width = _f_graph2_w , height = _f_graph2_h)

        self.f_main.update()


        # here starts the graph positioning stuffs
        # TODO : (DUNNO if still a thing.) The subplot somtimes does not calculated and set for example when the window is confugured between full screen and normal view
        # TODO : (DUNNO if still a thing.) Calculate teh graph margin for subplot, and create a default value array


        # TODO : I'm not 100% sure that the ticks visually the right place, however every time I checked it seemed to be good. May worth to keep this in mind.
        
        _graph_x_offset = self.p.canvas.winfo_x() + _f_main_x
        _graph_y_offset = _f_main_y

        _f_slider_w_new = _f_slider_w - (self.graph_margin[0] + self.graph_margin[1])   # this is for the tick only, the margins are subtracted from the whole width in here

        # graph ticks being calculared for graph_0
        _ticks = []         # stores date values
        _ticks_lb = []      # stores formated string values of the dates 
        _tick_amount = (math.floor(_f_slider_w_new / self.p.p.root.p.data.graph_tick_label_width_value))
        _tick_num_i = 0.5   # this means the tick is 0.5 day delayed on display, so the tick line will be exactly at the center/midday of the day
        for _tick_num in range(0,_tick_amount):
            _add_tick = self.p.p.root.p.data.date_min_lim + timedelta(days=(self.p.p.root.p.data.date_interval_lim / _tick_amount) * _tick_num_i)
            _ticks.append(_add_tick)
            _ticks_lb.append(_add_tick.strftime("%Y-%m-%d %H:%M"))
            _tick_num_i = _tick_num_i + 1


        #placing graph_0
        self.p.canv_graph_0.place(x = _graph_x_offset + _f_slider_x, y = _graph_y_offset + _f_slider_y, width = _f_slider_w, height = _f_slider_h)
        #self.p.graph_0._place()
        # TODO : This part crashes if the window is shrinked to a certain size ( possibly horizontal ), while there is a file loaded in and the filter is turned on. NEED TO CHECK LATER and add minimal window size as well.
        self.p.graph_0.fig.subplots_adjust(left=(self.graph_margin[0] / _f_slider_w), bottom=(self.graph_margin[3] / _f_slider_h), right=1 - (self.graph_margin[1] / _f_slider_w), top=1 - (self.graph_margin[2] / _f_slider_h), wspace=0, hspace=1)
        tk.Misc.lift(self.p.canv_graph_0, aboveThis=self.p.canvas)

        self.p.graph_0.fig_p1.set_xticks(_ticks)
        self.p.graph_0.fig_p1.set_xticklabels(_ticks_lb)
        #self.p.canv_graph_0.update()





        # graph ticks being re-calculared to fit grap_1 and graph_2
        _ticks = []
        _ticks_lb = []
        _tick_amount = (math.floor(_f_slider_w_new / self.p.p.root.p.data.graph_tick_label_width_value))
        _tick_num_i = 0.5
        for _tick_num in range(0,_tick_amount):
            _add_tick = self.p.p.root.p.data.date_min_cur + timedelta(days=(self.p.p.root.p.data.date_interval_cur / _tick_amount) * _tick_num_i)
            _ticks.append(_add_tick)
            _ticks_lb.append(_add_tick.strftime("%Y-%m-%d %H:%M"))
            _tick_num_i = _tick_num_i + 1

        #placing graph_1
        self.p.canv_graph_1.place(x = _graph_x_offset + _f_graph1_x, y = _graph_y_offset + _f_graph1_y, width = _f_graph1_w, height = _f_graph1_h)
        #self.p.graph_1._place()
        self.p.graph_1.fig.subplots_adjust(left=(self.graph_margin[0] / _f_graph1_w), bottom=(self.graph_margin[3] / _f_graph1_h), right=1 - (self.graph_margin[1] / _f_graph1_w), top=1 - (self.graph_margin[2] / _f_graph1_h), wspace=0, hspace=1)
        tk.Misc.lift(self.p.canv_graph_1, aboveThis=self.p.canvas)
        
        self.p.graph_1.fig_p1.set_xticks(_ticks)
        self.p.graph_1.fig_p1.set_xticklabels(_ticks_lb)
        #self.p.canv_graph_1.update()

        #placing graph_2
        self.p.canv_graph_2.place(x = _graph_x_offset + _f_graph2_x, y = _graph_y_offset + _f_graph2_y, width = _f_graph2_w, height = _f_graph2_h)
        #self.p.graph_2._place()
        self.p.graph_2.fig.subplots_adjust(left=(self.graph_margin[0] / _f_graph2_w), bottom=(self.graph_margin[3] / _f_graph2_h), right=1 - (self.graph_margin[1] / _f_graph2_w), top=1 - (self.graph_margin[2] / _f_graph2_h), wspace=0, hspace=1)
        tk.Misc.lift(self.p.canv_graph_2, aboveThis=self.p.canvas)

        self.p.graph_2.fig_p1.set_xticks(_ticks)
        self.p.graph_2.fig_p1.set_xticklabels(_ticks_lb)
        #self.p.canv_graph_2.update()

        # thinking about should this be needed here or not
        self.p.p.root.window.after(1, lambda: self.p.canv_graph_0.update())
        self.p.p.root.window.after(1, lambda: self.p.canv_graph_1.update())
        self.p.p.root.window.after(1, lambda: self.p.canv_graph_2.update())

        # ???
        print ("2--------------------------------- " + str(datetime.now()))
        
        
        # if snapshot not shrinked, setting graph for it
        if not (self.p.p.root.p.settings.data_view_snapshot_is_shrinked):
            #calc. coordinates
            _ss_x = _f_disp_setting_x + self.frame_margin + int(self.frame_margin / 2) + 50     # (50 is the size of the left side bar , and the graph_ss is on that canvas, not on the f_main)
            _ss_y = _f_disp_setting_y + self.frame_margin + int(self.frame_margin / 2) + self.f_snaps_lb_height
            _ss_w = _f_disp_setting_w - (self.frame_spacing * 1)
            _ss_h = _ss_w

            #independently gather snapshot events and stores them in a central variable
            _get_ss = []
            for _x_ss in self.p.p.root.p.data.dd_ss:
                _dt = parser.isoparse(_x_ss["DateTime"])
                if ((_dt > self.p.p.root.p.data.date_min_cur) and (_dt < self.p.p.root.p.data.date_max_cur)):
                    _get_ss.append(_x_ss)
            self.p.p.root.p.data.dd_ss_cur = _get_ss

            #placing listbox
            self.f_snap_listbox.place(x = 0, y = _ss_h + self.frame_spacing + self.f_snaps_lb_height, width = _ss_w - 20, height = _f_disp_setting_h - (self.frame_spacing * 1) -(_ss_h + self.frame_spacing) - self.f_snaps_lb_height)
            self.f_snap_listbox.delete(0,tk.END)
            self.f_snap_listbox_scrollbar.place(x = 0 + (_ss_w - 20), y = _ss_h + self.frame_spacing + self.f_snaps_lb_height , width = 20, height =  _f_disp_setting_h - (self.frame_spacing * 1) -(_ss_h + self.frame_spacing) - self.f_snaps_lb_height)

            # formats listbox content
            # TODO : This listbox content formating looks bad, needs a better methdo
            _headers = ["date", "                                   type", "graph"]
            _row_format ="{:<8}       {:<8}       {:<8}"
            self.f_snap_listbox.insert(0, _row_format.format(*_headers, sp=" "*2))
            for _x_ss in _get_ss:
                _items = [_x_ss["DateTime"],_x_ss["EventName"]]
                if ("LfpFrequencySnapshotEvents" in _x_ss):
                    _items.append("<--")
                else:
                    _items.append("")
                self.f_snap_listbox.insert(END, _row_format.format(*_items, sp=" "*2))


            #placing else and update
            self.p.canv_graph_ss.place(x = _ss_x, y = _ss_y, width = _ss_w , height = _ss_h)
            self.p.graph_ss._place()

            self.p.graph_ss.fig.subplots_adjust(left=(50 / _ss_w), bottom=(50 / _ss_h), right=1 - (5 / _ss_w), top=1 - (5 / _ss_h), wspace=0, hspace=1)
            tk.Misc.lift(self.p.canv_graph_ss, aboveThis=self.p.canvas)

            self.p.canv_graph_ss.update()
        
        else:
            self.f_snaps_viewer.place_forget()
            self.p.canv_graph_ss.place_forget()
 

 
        # TODO dunno if the updates are always neccecery.

        #updating x and ylims
        self.p.graph_0.xlim_reset = True
        self.p.graph_0.ylim_reset = True
        self.p.graph_1.xlim_reset = True
        self.p.graph_1.ylim_reset = True
        self.p.graph_2.xlim_reset = True
        self.p.graph_2.ylim_reset = True
        self.p.graph_ylim_set([self.p.graph_0], False)
        self.p.graph_ylim_set([self.p.graph_1,self.p.graph_2], True)

        #updating LFP lim for the entry field
        self.tb_e3.delete(0, tk.END)
        self.tb_e3.insert(0, str(self.p.p.root.p.data.lfp_max_displayable_value))
        
        #snapshot lim reset 
        # TODO : Dunno if this has anyt importnace.
        self.p.graph_ss.xlim_reset = True
        self.p.graph_ss.ylim_reset = True

        
        print ("3--------------------------------- " + str(datetime.now()))

        # TODO : There is a problem with the drwaing, that the graph_0 is drawn too early and in prong position
        # I do not really know whtat he source of the problem, but need to look into the configure function in the main file, and fix it. Only once that is fixed should I check this function again
        # Also other stuffs are needed to be cleaned in here

        #placing the graphs

        self.p.p.root.window.after(1, lambda: self.p.canv_graph_0.update_idletasks())
        self.p.p.root.window.after(1, lambda: self.p.canv_graph_1.update_idletasks())
        self.p.p.root.window.after(1, lambda: self.p.canv_graph_2.update_idletasks())


        self.p.p.root.window.after(1, lambda: self.p.graph_0._place([self.p.canv_graph_0.winfo_width(),self.p.canv_graph_0.winfo_height()]))
        self.p.p.root.window.after(1, lambda: self.p.graph_1._place([self.p.canv_graph_1.winfo_width(),self.p.canv_graph_1.winfo_height()]))
        self.p.p.root.window.after(1, lambda: self.p.graph_2._place([self.p.canv_graph_2.winfo_width(),self.p.canv_graph_2.winfo_height()]))

        self.p.graph_ss._place() 


        self.rectangle_action()

        print ("4--------------------------------- " + str(datetime.now()))
        gc.collect


        # TODO : Try to add a synced drawing of graphs, with .after 0 here
        self.p.p.root.window.after(1, lambda: self.p.graph_0.draw())
        self.p.p.root.window.after(1, lambda: self.p.graph_1.draw())
        self.p.p.root.window.after(1, lambda: self.p.graph_2.draw())

        print ("5--------------------------------- " + str(datetime.now()))
        self.p.b_content_isloading = False












### RELATED CLASSES ###

# display filter submenu's structure
class ui_f_disps():
    def __init__(self, parent, bindedto, config_):
        self.p = parent
        self.config_ = config_
        self.bindedto = bindedto

        self.btn_m = 1
        self.margin = 1
        self.intendation_value = 5
        self.x = self.config_[4][0]
        self.y = self.config_[4][1]
        self.w = self.config_[4][2]
        self.h = self.config_[4][3]
        self.name = self.config_[0]
        self.intendation = self.config_[1]
        self.text = self.config_[2]
        if ((self.text).isdigit()):
             self.text = self.p.p.p.root.p.data.list_of_event_types[int(self.text)]
        self.btn_cfg = self.config_[3]

        self.f = Frame (self.bindedto, name=("f_disps_" + str(self.name)), bg="grey95", bd = 0, highlightthickness = 0)
        self.lb = Label(self.f, name=("f_lb_" + str(self.name)), bg="tan1", text=self.text, anchor="w", bd = 0, highlightthickness = 0)
        self.btn = ""   

        if (len(self.btn_cfg) != 0):
            self.btn = btn_toogle(self, self.f , [[(self.w - self.h), self.btn_m, (self.h - (self.margin * 2)), (self.h - (self.margin * 2))],self.btn_cfg[1],self.btn_cfg[2]])
                

    # regular drawing
    def draw(self):
        print ("drawing (data side submenu): " + self.name)
        self.f.place(x = self.x , y = self.y, width = self.w, height = self.h)
        self.lb.place(x = self.margin + (self.intendation_value * self.intendation), y = self.margin, width = self.w - (self.margin * 2) - (self.intendation_value * self.intendation), height = self.h - (self.margin * 2))
        if (self.btn != ""):
            self.btn.draw()


#state container class for toogle buttons ( related to display side menu )
class btn_toogle_state():
    def __init__(self,parent,config_):
        self.p = parent
        self.config_ = config_
        self.name_org = self.config_[0]
        self.name = self.config_[0] + "_" + self.config_[2]
        self.color = self.config_[1]
        self.text =self.config_[2]
        self.value = self.config_[3]
        self.name_parent = self.config_[4]

        
#button container class for toogle buttons ( related to display side menu )
class btn_toogle():
    def __init__(self, parent, bindedto, config_):
        self.p = parent
        self.bindedto = bindedto
        
        self.config_ = config_      # [[xywh], [["state_on","green","ON",True], ["state_off","red","OFF",False], False]]
        self.x = self.config_[0][0]
        self.y = self.config_[0][1]
        self.w = self.config_[0][2]
        self.h = self.config_[0][3]

        self.ison = self.config_[2]
        self.state_on = btn_toogle_state(self,self.config_[1][0])   # exaple input["state_off","red","OFF",False]
        self.state_off = btn_toogle_state(self,self.config_[1][1])
        self.holder_states = [self.state_on, self.state_off]
        self.state_cur = ""
        
        # finds which graph the plot is from and sets visibility here if it is really visible ( this code is weird, but works tho ) 
        _g = None
        for _g_ in [self.p.p.p.graph_1, self.p.p.p.graph_2]:
            if (self.state_on.name_parent == _g_.name):
                _g = _g_

        if (_g != None):
            _plo = _g.get_plot(self.state_on.name_org)
            if (_plo != None):
                self.ison = _plo.visibile
        
        if (self.ison):
            self.state_cur = self.state_on
        else:
            self.state_cur = self.state_off

        # creates UI button itself
        self.btn = Button(self.bindedto, text="", bg="blue", command=  lambda: self.press(), relief=FLAT, bd= 0, highlightthickness = 0)


        self.draw()


    #action for the button (change visibility and update status)
    def press(self):
        _g = None
        for _g_ in [self.p.p.p.graph_1, self.p.p.p.graph_2]:
            print (str([self.state_cur.name_parent,_g_.name]))
            if (self.state_cur.name_parent == _g_.name):
                _g = _g_

        if (_g != None):
            _plo = _g.get_plot(self.state_cur.name_org)
            if (_plo != None):
                _plo.visibile = not(self.state_cur.value)
                _plo.b_changed_settings = True
                _plo.p.p.p.root.content.draw()
            
                if (self.ison):
                    self.ison = False
                    self.state_cur = self.state_off
                else:
                    self.ison = True
                    self.state_cur = self.state_on

                self.draw()

    #draw and update stuffs
    def draw(self):
        self.btn.configure(text=self.state_cur.text)
        self.btn.configure(bg=self.state_cur.color)
        self.btn.place(x = self.x + self.p.margin, y = self.y, width = self.w - self.p.margin, height = self.h - self.p.margin)



